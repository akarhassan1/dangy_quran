import React from 'react';
import { Play, Pause, X } from 'lucide-react';

export default function MiniPlayer({ 
  currentTrack, 
  isPlaying, 
  onTogglePlay, 
  onOpenFullPlayer,
  onClosePlayer,
  darkMode
}) {
  if (!currentTrack) return null;

  const fallbackLogo = darkMode || (typeof document !== 'undefined' && document.documentElement.classList.contains('dark'))
    ? '/images/logo_dark.png' 
    : '/images/logo_light.png';

  const photoSrc = currentTrack.reciterPhoto || fallbackLogo;

  return (
    <div 
      onClick={onOpenFullPlayer}
      className="fixed bottom-[calc(0.75rem+env(safe-area-inset-bottom,0px))] left-3 right-3 max-w-md mx-auto z-40 bg-[#14a489] dark:bg-blue-950/95 backdrop-blur-xl text-white rounded-2xl p-3 shadow-xl border border-white/20 dark:border-blue-700/40 flex items-center justify-between cursor-pointer group hover:scale-[1.01] transition-all font-kufic"
    >
      {/* Right: Avatar & Track info */}
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-xl overflow-hidden shadow-md shrink-0 border border-white/20 bg-white dark:bg-[#011142] flex items-center justify-center">
          <img 
            src={photoSrc} 
            alt={currentTrack.reciterName}
            className="w-full h-full object-cover"
            onError={(e) => {
              e.target.onerror = null;
              e.target.src = fallbackLogo;
            }}
          />
        </div>

        <div className="text-right">
          <div className="flex items-center gap-2">
            <h4 className="font-bold text-sm text-white line-clamp-1">
              سورة {currentTrack.surahName}
            </h4>
            <span className="text-xs text-emerald-100 dark:text-blue-200">({currentTrack.surahKurdish})</span>
          </div>
          <p className="text-xs text-white/80 line-clamp-1">
            {currentTrack.reciterName}
          </p>
        </div>
      </div>

      {/* Left: Controls */}
      <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
        {/* Animated Equalizer */}
        {isPlaying && (
          <div className="flex items-end gap-0.5 h-4 px-2">
            <div className="w-1 bg-white rounded-full animate-eq-1" />
            <div className="w-1 bg-white rounded-full animate-eq-2" />
            <div className="w-1 bg-white rounded-full animate-eq-3" />
          </div>
        )}

        {/* Play/Pause Button */}
        <button
          onClick={onTogglePlay}
          className="w-10 h-10 rounded-full bg-white text-[#14a489] dark:text-blue-900 flex items-center justify-center shadow-md hover:scale-105 active:scale-95 transition-all cursor-pointer"
        >
          {isPlaying ? (
            <Pause className="w-5 h-5 fill-current" />
          ) : (
            <Play className="w-5 h-5 fill-current ml-0.5" />
          )}
        </button>

        {/* Close Button */}
        <button
          onClick={onClosePlayer}
          className="p-2 text-white/70 hover:text-white transition-colors cursor-pointer"
          title="داخستنی پەخشکەر"
        >
          <X className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}
