import React, { useState, useEffect, useRef } from 'react';
import { ChevronRight, Tv, Volume2, VolumeX, Play, Pause, Maximize2, Minimize2, RotateCcw, AlertCircle } from 'lucide-react';
import Hls from 'hls.js';

const LIVE_CHANNELS = [
  {
    id: 'makkah',
    name: 'پەخشی ڕاستەوخۆی مەکەی پیرۆز',
    arabicName: 'قناة القرآن الكريم - بث مباشر من الحرم المكي',
    icon: '🕋',
    streamUrl: 'https://win.holol.com/live/quran/playlist.m3u8'
  },
  {
    id: 'madinah',
    name: 'پەخشی ڕاستەوخۆی مەدینەی منەوەرە',
    arabicName: 'قناة السنة النبوية - بث مباشر من المسجد النبوي',
    icon: '🕌',
    streamUrl: 'https://win.holol.com/live/sunnah/playlist.m3u8'
  }
];

export default function RadioScreen({ onBack }) {
  const [activeChannelId, setActiveChannelId] = useState('makkah');
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [buffering, setBuffering] = useState(true);
  const [streamError, setStreamError] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);

  const activeChannel = LIVE_CHANNELS.find(c => c.id === activeChannelId) || LIVE_CHANNELS[0];

  const videoRef = useRef(null);
  const containerRef = useRef(null);
  const hlsRef = useRef(null);

  // Fullscreen change listener
  useEffect(() => {
    function handleFullscreenChange() {
      const isFull = !!(document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement);
      setIsFullscreen(isFull);
    }

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    document.addEventListener('webkitfullscreenchange', handleFullscreenChange);
    document.addEventListener('mozfullscreenchange', handleFullscreenChange);

    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
      document.removeEventListener('webkitfullscreenchange', handleFullscreenChange);
      document.removeEventListener('mozfullscreenchange', handleFullscreenChange);
    };
  }, []);

  const toggleFullscreen = async () => {
    const container = containerRef.current;
    if (!container) return;

    try {
      if (!isFullscreen) {
        if (container.requestFullscreen) {
          await container.requestFullscreen();
        } else if (container.webkitRequestFullscreen) {
          await container.webkitRequestFullscreen();
        } else if (container.mozRequestFullScreen) {
          await container.mozRequestFullScreen();
        }
        setIsFullscreen(true);
      } else {
        if (document.exitFullscreen) {
          await document.exitFullscreen();
        } else if (document.webkitExitFullscreen) {
          await document.webkitExitFullscreen();
        }
        setIsFullscreen(false);
      }
    } catch (e) {
      setIsFullscreen(!isFullscreen);
    }
  };

  const handleSelectChannel = (channelId) => {
    if (activeChannelId === channelId) return;
    setActiveChannelId(channelId);
    setStreamError(false);
    setBuffering(true);
    setIsPlaying(false);
  };

  const togglePlay = () => {
    const video = videoRef.current;
    if (!video) return;

    if (video.paused) {
      const playPromise = video.play();
      if (playPromise !== undefined) {
        playPromise.then(() => {
          setIsPlaying(true);
          setBuffering(false);
          setStreamError(false);
        }).catch(err => {
          console.warn('Play was prevented:', err);
        });
      }
    } else {
      video.pause();
      setIsPlaying(false);
    }
  };

  const toggleMute = () => {
    const video = videoRef.current;
    if (!video) return;
    video.muted = !video.muted;
    setIsMuted(video.muted);
  };

  const startStream = () => {
    const video = videoRef.current;
    if (!video) return;

    setBuffering(true);
    setStreamError(false);

    if (hlsRef.current) {
      try {
        hlsRef.current.destroy();
      } catch (e) {}
      hlsRef.current = null;
    }

    const streamUrl = activeChannel.streamUrl;

    video.setAttribute('playsinline', 'true');
    video.setAttribute('webkit-playsinline', 'true');
    video.setAttribute('x5-playsinline', 'true');
    video.crossOrigin = 'anonymous';

    if (Hls.isSupported()) {
      try {
        const hls = new Hls({
          enableWorker: false,
          lowLatencyMode: false,
          backBufferLength: 30,
          maxBufferLength: 20,
          maxMaxBufferLength: 40,
          maxBufferSize: 30 * 1000 * 1000,
          liveSyncDurationCount: 3,
          liveMaxLatencyDurationCount: 10,
          manifestLoadingTimeOut: 25000,
          manifestLoadingMaxRetry: 6,
          levelLoadingTimeOut: 25000,
          levelLoadingMaxRetry: 6,
          fragLoadingTimeOut: 25000,
          fragLoadingMaxRetry: 6,
          startFragPrefetch: true,
          xhrSetup: (xhr) => {
            xhr.withCredentials = false;
          }
        });

        hlsRef.current = hls;
        hls.loadSource(streamUrl);
        hls.attachMedia(video);

        hls.on(Hls.Events.MANIFEST_PARSED, () => {
          setBuffering(false);
          video.muted = isMuted;
          const p = video.play();
          if (p !== undefined) {
            p.then(() => {
              setIsPlaying(true);
              setBuffering(false);
            }).catch(() => {
              setIsPlaying(false);
            });
          }
        });

        hls.on(Hls.Events.ERROR, (event, data) => {
          if (data.fatal) {
            switch (data.type) {
              case Hls.ErrorTypes.NETWORK_ERROR:
                console.warn('Network error, attempting reload...', data);
                hls.startLoad();
                break;
              case Hls.ErrorTypes.MEDIA_ERROR:
                console.warn('Media error, recovering...', data);
                hls.recoverMediaError();
                break;
              default:
                console.warn('Fatal HLS error, switching to native video...', data);
                try {
                  hls.destroy();
                } catch (e) {}
                hlsRef.current = null;
                video.src = streamUrl;
                video.load();
                video.play().then(() => {
                  setIsPlaying(true);
                  setBuffering(false);
                }).catch(() => {
                  setStreamError(true);
                  setBuffering(false);
                });
                break;
            }
          }
        });
      } catch (err) {
        console.error('HLS error:', err);
        video.src = streamUrl;
        video.load();
        video.play().then(() => {
          setIsPlaying(true);
          setBuffering(false);
        }).catch(() => {
          setStreamError(true);
          setBuffering(false);
        });
      }
    } else {
      video.src = streamUrl;
      video.load();
      video.play().then(() => {
        setIsPlaying(true);
        setBuffering(false);
      }).catch(() => {
        setStreamError(true);
        setBuffering(false);
      });
    }
  };

  useEffect(() => {
    startStream();

    const video = videoRef.current;
    if (video) {
      const onPlaying = () => {
        setIsPlaying(true);
        setBuffering(false);
        setStreamError(false);
      };
      const onPause = () => setIsPlaying(false);
      const onWaiting = () => setBuffering(true);
      const onCanPlay = () => setBuffering(false);
      const onError = () => {
        setBuffering(false);
        setStreamError(true);
      };

      video.addEventListener('playing', onPlaying);
      video.addEventListener('pause', onPause);
      video.addEventListener('waiting', onWaiting);
      video.addEventListener('canplay', onCanPlay);
      video.addEventListener('error', onError);

      return () => {
        video.removeEventListener('playing', onPlaying);
        video.removeEventListener('pause', onPause);
        video.removeEventListener('waiting', onWaiting);
        video.removeEventListener('canplay', onCanPlay);
        video.removeEventListener('error', onError);
        if (hlsRef.current) {
          try {
            hlsRef.current.destroy();
          } catch (e) {}
          hlsRef.current = null;
        }
      };
    }
  }, [activeChannelId]);

  return (
    <div className="min-h-screen pb-28 font-kufic bg-slate-50 dark:bg-[#011142] text-slate-800 dark:text-white transition-colors duration-300">
      {/* Header Banner */}
      <div className="bg-[#14a489] dark:bg-blue-900/80 text-white pt-12 sm:pt-6 pb-6 px-6 shadow-sm">
        <div className="max-w-xl mx-auto flex items-center justify-between">
          <button 
            onClick={onBack}
            className="flex items-center gap-2 hover:opacity-80 active:scale-95 transition-all font-semibold cursor-pointer text-white"
          >
            <ChevronRight className="w-6 h-6" />
            <span className="text-lg">گەڕانەوە</span>
          </button>
        </div>

        <div className="max-w-xl mx-auto text-center pt-3 pb-1">
          <h1 className="text-2xl sm:text-3xl font-extrabold flex items-center justify-center gap-2">
            <span>پەخشی ڕاستەوخۆ</span>
            <Tv className="w-7 h-7" />
          </h1>
          <p className="text-emerald-100 dark:text-blue-200 text-xs sm:text-sm mt-1">پەخشی ڕاستەوخۆی مەکەی پیرۆز و مەدینەی منەوەرە بە کوالێتی بەرز</p>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="max-w-xl mx-auto px-4 pt-6 space-y-5">
        {/* Channel Selection Tabs */}
        <div className="grid grid-cols-2 gap-3">
          {LIVE_CHANNELS.map((channel) => {
            const isActive = activeChannel.id === channel.id;
            return (
              <button
                key={channel.id}
                onClick={() => handleSelectChannel(channel.id)}
                className={`py-4 px-3 rounded-2xl border transition-all cursor-pointer font-bold text-sm flex flex-col items-center justify-center gap-2 shadow-sm ${
                  isActive
                    ? 'bg-[#14a489] dark:bg-blue-600 text-white border-transparent scale-[1.02]'
                    : 'bg-white dark:bg-blue-950/40 text-slate-700 dark:text-slate-200 border-slate-200 dark:border-blue-900/40 hover:border-[#14a489]'
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="text-lg">{channel.icon}</span>
                  <span>{channel.id === 'makkah' ? 'مەکەی پیرۆز' : 'مەدینەی منەوەرە'}</span>
                </div>
                {isActive && (
                  <span className="text-[10px] bg-white/20 px-2.5 py-0.5 rounded-full flex items-center gap-1 animate-pulse">
                    <span className="w-2 h-2 rounded-full bg-emerald-300" />
                    <span>ڕاستەوخۆ</span>
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Video Player Container */}
        <div 
          ref={containerRef}
          className={`bg-black rounded-3xl overflow-hidden shadow-2xl border border-slate-800 relative group transition-all ${
            isFullscreen 
              ? 'fixed inset-0 z-50 rounded-none border-none flex items-center justify-center bg-black w-screen h-screen' 
              : 'aspect-video flex items-center justify-center'
          }`}
          onClick={(e) => {
            if (e.target.tagName !== 'BUTTON') {
              togglePlay();
            }
          }}
        >
          <video
            ref={videoRef}
            className="w-full h-full object-contain cursor-pointer bg-black"
            playsInline
            webkit-playsinline="true"
            x5-playsinline="true"
            autoPlay
          />

          {/* Center Play Button when paused */}
          {!isPlaying && !streamError && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                togglePlay();
              }}
              className="absolute inset-0 m-auto w-18 h-18 bg-[#14a489] hover:bg-[#118f77] text-white rounded-full flex items-center justify-center shadow-2xl active:scale-95 transition-all z-20 cursor-pointer border-2 border-white/40"
              title="دەستپێکردنی پەخش"
            >
              <Play className="w-9 h-9 translate-x-0.5 fill-current" />
            </button>
          )}

          {/* Buffering Indicator in Corner */}
          {buffering && !streamError && (
            <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-md px-3 py-1.5 rounded-xl flex items-center gap-2 text-white text-xs z-20 pointer-events-none">
              <div className="w-3.5 h-3.5 border-2 border-emerald-400 border-t-transparent rounded-full animate-spin" />
              <span>پەیوەست دەبێت...</span>
            </div>
          )}

          {/* Top Controls Overlay */}
          <div className="absolute top-3 right-3 z-20 flex items-center gap-2 pointer-events-none">
            {/* Live Indicator */}
            <div className="bg-red-600/90 text-white text-[11px] font-bold px-3 py-1 rounded-full flex items-center gap-1.5 shadow-md">
              <span className="w-2 h-2 rounded-full bg-white animate-ping" />
              <span>LIVE</span>
            </div>

            {/* Fullscreen Button */}
            <button
              onClick={(e) => {
                e.stopPropagation();
                toggleFullscreen();
              }}
              className="bg-black/70 hover:bg-black/90 backdrop-blur-md text-white p-2 rounded-xl border border-white/20 shadow-lg active:scale-95 transition-all flex items-center gap-1.5 text-xs font-bold cursor-pointer pointer-events-auto"
              title={isFullscreen ? 'دەرچوون لە فول سکرین' : 'فول سکرین'}
            >
              {isFullscreen ? (
                <>
                  <Minimize2 className="w-4 h-4 text-emerald-400" />
                  <span className="hidden sm:inline">دەرچوون</span>
                </>
              ) : (
                <>
                  <Maximize2 className="w-4 h-4 text-emerald-400" />
                  <span>فول سکرین</span>
                </>
              )}
            </button>
          </div>

          {/* Bottom Floating Control Bar */}
          <div className="absolute bottom-3 left-3 right-3 z-20 flex items-center justify-between bg-black/60 backdrop-blur-md px-4 py-2 rounded-2xl border border-white/10 text-white">
            <div className="flex items-center gap-3">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  togglePlay();
                }}
                className="p-1.5 hover:text-emerald-400 active:scale-90 transition-all cursor-pointer"
              >
                {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
              </button>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  toggleMute();
                }}
                className="p-1.5 hover:text-emerald-400 active:scale-90 transition-all cursor-pointer"
              >
                {isMuted ? <VolumeX className="w-5 h-5 text-red-400" /> : <Volume2 className="w-5 h-5" />}
              </button>
            </div>

            <button
              onClick={(e) => {
                e.stopPropagation();
                startStream();
              }}
              className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 hover:text-emerald-300 cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>نوێکردنەوە</span>
            </button>
          </div>

          {/* Error Fallback */}
          {streamError && (
            <div className="absolute inset-0 bg-black/90 p-6 flex flex-col items-center justify-center gap-3 text-center text-white z-30">
              <AlertCircle className="w-10 h-10 text-rose-500" />
              <h4 className="font-bold text-sm">نەتوانرا پەخشەکە بکرێتەوە</h4>
              <p className="text-xs text-slate-400">تکایە دڵنیابەرەوە لە هەبوونی ئینتەرنێت و دووبارە هەوڵبدەرەوە.</p>
              <button 
                onClick={(e) => {
                  e.stopPropagation();
                  startStream();
                }}
                className="mt-2 py-2 px-5 bg-[#14a489] text-white rounded-xl text-xs font-bold cursor-pointer hover:opacity-90 active:scale-95 transition-all flex items-center gap-2"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>دووبارە هەوڵبدەرەوە</span>
              </button>
            </div>
          )}
        </div>

        {/* Channel Info Card */}
        <div className="bg-white dark:bg-blue-950/40 p-4 rounded-2xl border border-slate-200 dark:border-blue-900/40 text-right space-y-1 shadow-sm">
          <h3 className="font-bold text-base text-slate-800 dark:text-slate-100 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
            <span>{activeChannel.name}</span>
          </h3>
          <p className="text-xs sm:text-sm font-bold text-[#14a489] dark:text-blue-300 leading-relaxed">
            {activeChannel.arabicName}
          </p>
        </div>
      </div>
    </div>
  );
}
