import React from 'react';
import { Sliders, Info, Moon, Sun, Tv, BookOpen, Download } from 'lucide-react';

export default function HomeScreen({ 
  onNavigate, 
  onOpenSettings, 
  onOpenInfo, 
  darkMode, 
  setDarkMode 
}) {
  return (
    <div className="min-h-screen pb-28 font-kufic bg-slate-50 dark:bg-[#011142] text-slate-800 dark:text-white transition-colors duration-300 relative overflow-hidden">
      {/* Background SVG Image home_bg.svg with 80% opacity and full screen fit */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-80 dark:opacity-40 pointer-events-none z-0"
        style={{ backgroundImage: `url('/home_bg.svg')` }}
      />

      <div className="relative z-10">
        {/* Top Bar with Action Icons on TOP-LEFT (pt-12 for status bar clearance) */}
        <div className="pt-12 sm:pt-8 px-5 max-w-md sm:max-w-xl mx-auto flex items-center justify-start">
          <div className="flex items-center gap-2.5 sm:gap-3">
            {/* Info Button */}
            <button 
              onClick={onOpenInfo}
              className="w-12 h-12 sm:w-14 sm:h-14 bg-[#14a489] dark:bg-blue-950/80 text-white rounded-2xl flex items-center justify-center hover:opacity-90 active:scale-95 transition-all cursor-pointer shadow-sm border border-transparent dark:border-blue-700/40"
              title="دەربارەی بەرنامە"
            >
              <Info className="w-5 h-5 sm:w-7 sm:h-7" />
            </button>

            {/* Settings Button */}
            <button 
              onClick={onOpenSettings}
              className="w-12 h-12 sm:w-14 sm:h-14 bg-[#14a489] dark:bg-blue-950/80 text-white rounded-2xl flex items-center justify-center hover:opacity-90 active:scale-95 transition-all cursor-pointer shadow-sm border border-transparent dark:border-blue-700/40"
              title="ڕێکخستنەکان"
            >
              <Sliders className="w-5 h-5 sm:w-7 sm:h-7" />
            </button>

            {/* Downloads Screen Button (Swapped to Dark Mode's previous position) */}
            <button 
              onClick={() => onNavigate('downloads')}
              className="w-12 h-12 sm:w-14 sm:h-14 bg-[#14a489] dark:bg-blue-950/80 text-white rounded-2xl flex items-center justify-center hover:opacity-90 active:scale-95 transition-all cursor-pointer shadow-sm border border-transparent dark:border-blue-700/40"
              title="داونلۆدکراوەکان"
            >
              <Download className="w-5 h-5 sm:w-7 sm:h-7" />
            </button>

            {/* Dark / Light Mode Toggle Button (Swapped to Downloads' previous position) */}
            <button 
              onClick={() => setDarkMode(!darkMode)}
              className="w-12 h-12 sm:w-14 sm:h-14 bg-[#14a489] dark:bg-blue-950/80 text-white rounded-2xl flex items-center justify-center hover:opacity-90 active:scale-95 transition-all cursor-pointer shadow-sm border border-transparent dark:border-blue-700/40"
              title="گۆڕینی دۆخ"
            >
              {darkMode ? <Sun className="w-5 h-5 sm:w-7 sm:h-7 text-amber-300" /> : <Moon className="w-5 h-5 sm:w-7 sm:h-7" />}
            </button>
          </div>
        </div>

        <div className="max-w-md sm:max-w-xl mx-auto px-5 pt-6 space-y-6">
          {/* Hadith Quote Card */}
          <div className="bg-[#14a489] dark:bg-blue-900/80 text-white rounded-3xl px-3 py-5 sm:p-7 shadow-sm text-center space-y-3 transition-colors border border-transparent dark:border-blue-800/50 overflow-hidden">
            <h2 className="text-[17px] sm:text-2xl font-bold leading-relaxed whitespace-nowrap overflow-hidden text-ellipsis">
              لەمنەوە بیگەیێنن ئەگەر ئایەتێکیش بێت
            </h2>
            <div className="flex items-center justify-center gap-3 pt-1">
              <div className="h-0.5 w-12 bg-white/30 rounded-full" />
              <span className="text-sm font-semibold text-emerald-100 dark:text-blue-200 font-arabic whitespace-nowrap">
                — پێغەمبەرمان ﷺ —
              </span>
              <div className="h-0.5 w-12 bg-white/30 rounded-full" />
            </div>
          </div>

          {/* 2 MAIN BUTTONS */}
          <div className="grid grid-cols-2 gap-4 pt-2">
            {/* Button 1: Holy Quran (قورئانی پیرۆز) */}
            <button
              onClick={() => onNavigate('reciters')}
              className="bg-[#14a489] dark:bg-blue-900/90 hover:opacity-95 active:scale-95 text-white rounded-3xl p-5 sm:p-6 flex flex-col items-center justify-center gap-4 shadow-sm transition-all cursor-pointer h-40 sm:h-48 border border-transparent dark:border-blue-700/50 group"
            >
              <BookOpen className="w-14 h-14 sm:w-16 sm:h-16 text-white group-hover:scale-105 transition-transform" />
              <span className="font-extrabold text-lg sm:text-xl text-center leading-tight">
                قورئانی پیرۆز
              </span>
            </button>

            {/* Button 2: Live Broadcast (پەخشی ڕاستەوخۆ) */}
            <button
              onClick={() => onNavigate('radio')}
              className="bg-[#14a489] dark:bg-blue-900/90 hover:opacity-95 active:scale-95 text-white rounded-3xl p-5 sm:p-6 flex flex-col items-center justify-center gap-4 shadow-sm transition-all cursor-pointer h-40 sm:h-48 border border-transparent dark:border-blue-700/50 group"
            >
              <div className="relative group-hover:scale-105 transition-transform">
                <Tv className="w-14 h-14 sm:w-16 sm:h-16 text-white" />
                <span className="absolute top-1 right-1 w-3 h-3 rounded-full bg-red-400 animate-ping" />
              </div>
              <span className="font-extrabold text-lg sm:text-xl text-center leading-tight">
                پەخشی ڕاستەوخۆ
              </span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
