import React, { useState, useEffect, useRef } from 'react';
import { 
  ChevronRight, 
  Download, 
  Play, 
  Pause, 
  SkipBack, 
  SkipForward, 
  Check, 
  Palette, 
  X, 
  Volume2, 
  VolumeX, 
  Sparkles,
  Maximize2,
  Film,
  CloudRain,
  Waves,
  Wind,
  Flame,
  Bird,
  Droplets
} from 'lucide-react';
import { getSurahAudioUrl } from '../services/reciterData';
import { saveAudioOffline, downloadFileToDisk, isAudioOffline, fetchAudioBlob } from '../services/offlineStorage';

// Available Video Background Options with WHITE icons
const VIDEO_OPTIONS = [
  { id: 'default', name: 'باکگراوندی ئاسایی', icon: Film, url: '/quran_screen/videos/background/playerBackground.mp4' },
  { id: 'rain', name: 'ڤیدیۆی باران', icon: CloudRain, url: '/quran_screen/videos/background/rain_video_full.mp4' },
  { id: 'wave', name: 'ڤیدیۆی دەريا', icon: Waves, url: '/quran_screen/videos/background/wave_video_full.mp4' },
  { id: 'wind', name: 'ڤیدیۆی با و سروشت', icon: Wind, url: '/quran_screen/videos/background/wind_video_full.mp4' },
  { id: 'bonfire', name: 'ڤیدیۆی ئاگر', icon: Flame, url: '/quran_screen/videos/background/bonfire_video_full.mp4' },
  { id: 'birds', name: 'ڤیدیۆی بەیانی و باڵندە', icon: Bird, url: '/quran_screen/videos/background/morning_birds_full.mp4' }
];

// Available Ambient Sound Effect Options with WHITE icons
const AMBIENT_SOUND_OPTIONS = [
  { id: 'none', name: 'بێ ساوند ئیفێکت', icon: VolumeX, url: '' },
  { id: 'rain', name: 'دەنگی باران', icon: CloudRain, url: '/quran_screen/audio/calm_rain.mp3' },
  { id: 'wave', name: 'دەنگی دەريا', icon: Waves, url: '/quran_screen/audio/wave_effect.mp3' },
  { id: 'wind', name: 'دەنگی با', icon: Wind, url: '/quran_screen/audio/light_wind.mp3' },
  { id: 'bonfire', name: 'دەنگی ئاگر', icon: Flame, url: '/quran_screen/audio/calm_bonfire.mp3' },
  { id: 'birds', name: 'دەنگی باڵندەکان', icon: Bird, url: '/quran_screen/audio/morning_birds.mp3' },
  { id: 'river', name: 'دەنگی ڕووبار', icon: Droplets, url: '/quran_screen/audio/calm_river.mp3' }
];

export default function PlayerScreen({ 
  currentTrack, 
  isPlaying, 
  onTogglePlay, 
  onNextTrack, 
  onPrevTrack, 
  currentTime, 
  duration, 
  onSeek, 
  onBack 
}) {
  const [isOfflineReady, setIsOfflineReady] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);

  // Immersive Fullscreen Mode State
  const [isFullscreenView, setIsFullscreenView] = useState(false);

  // Persistent Settings: Video background, Ambient Sound, and Volume stored in localStorage
  const [selectedVideo, setSelectedVideo] = useState(() => {
    return localStorage.getItem('dangy_selected_video') || VIDEO_OPTIONS[0].url;
  });

  const [selectedAmbient, setSelectedAmbient] = useState(() => {
    const savedId = localStorage.getItem('dangy_selected_ambient_id');
    if (savedId) {
      const found = AMBIENT_SOUND_OPTIONS.find(a => a.id === savedId);
      if (found) return found;
    }
    return AMBIENT_SOUND_OPTIONS[0];
  });

  const [ambientVolume, setAmbientVolume] = useState(() => {
    const savedVol = localStorage.getItem('dangy_ambient_volume');
    return savedVol !== null ? parseFloat(savedVol) : 0.20;
  });

  const [isBgModalOpen, setIsBgModalOpen] = useState(false);

  // Video background element ref and smooth loading state
  const videoRef = useRef(null);
  const [isVideoLoaded, setIsVideoLoaded] = useState(false);

  // Ambient Audio HTML5 element ref
  const ambientAudioRef = useRef(new Audio());

  // Handle video autoplay smoothly across all Android versions without lag or black screen
  useEffect(() => {
    setIsVideoLoaded(false);
    const video = videoRef.current;
    if (video && selectedVideo) {
      video.muted = true;
      video.defaultMuted = true;
      video.playsInline = true;
      video.setAttribute('playsinline', '');
      video.setAttribute('webkit-playsinline', '');
      video.setAttribute('x5-playsinline', '');
      video.setAttribute('muted', '');
      
      try {
        video.load();
      } catch (e) {}

      const attemptPlay = () => {
        const playPromise = video.play();
        if (playPromise !== undefined) {
          playPromise
            .then(() => setIsVideoLoaded(true))
            .catch(() => {
              video.muted = true;
              video.play().then(() => setIsVideoLoaded(true)).catch(() => {});
            });
        }
      };

      attemptPlay();
    }
  }, [selectedVideo]);

  // Save selected video background to localStorage
  const handleSelectVideo = (videoUrl) => {
    setSelectedVideo(videoUrl);
    localStorage.setItem('dangy_selected_video', videoUrl);
  };

  // Save selected ambient sound to localStorage
  const handleSelectAmbient = (ambientOption) => {
    setSelectedAmbient(ambientOption);
    localStorage.setItem('dangy_selected_ambient_id', ambientOption.id);
  };

  // Save volume to localStorage
  const handleVolumeChange = (vol) => {
    setAmbientVolume(vol);
    localStorage.setItem('dangy_ambient_volume', String(vol));
  };

  // Check offline status
  useEffect(() => {
    async function checkOffline() {
      if (currentTrack) {
        const cached = await isAudioOffline(currentTrack.surahId, currentTrack.reciterId);
        setIsOfflineReady(cached);
      }
    }
    checkOffline();
  }, [currentTrack]);

  // Ambient audio playback management
  useEffect(() => {
    const ambientAudio = ambientAudioRef.current;
    ambientAudio.loop = true;
    ambientAudio.volume = ambientVolume;

    if (selectedAmbient.url && isPlaying) {
      if (ambientAudio.src !== window.location.origin + selectedAmbient.url) {
        ambientAudio.src = selectedAmbient.url;
      }
      ambientAudio.play().catch(e => console.log('Ambient sound play error', e));
    } else {
      ambientAudio.pause();
    }

    return () => {
      ambientAudio.pause();
    };
  }, [selectedAmbient, isPlaying, ambientVolume]);

  if (!currentTrack) return null;

  // Format seconds to 00:00
  const formatTime = (secs) => {
    if (!secs || isNaN(secs)) return '00:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const handlePlayerDownload = async () => {
    if (isDownloading) return;
    try {
      setIsDownloading(true);
      const audioUrl = currentTrack.isRadio 
        ? currentTrack.audioUrl 
        : getSurahAudioUrl(currentTrack.reciterServer, currentTrack.surahId);

      const blob = await fetchAudioBlob(audioUrl);

      const meta = {
        surahName: currentTrack.surahKurdish,
        surahArabic: currentTrack.surahName,
        reciterName: currentTrack.reciterName,
        reciterPhoto: currentTrack.reciterPhoto,
        reciterServer: currentTrack.reciterServer
      };

      await saveAudioOffline(currentTrack.surahId, currentTrack.reciterId, blob, meta);
      setIsOfflineReady(true);

      downloadFileToDisk(blob, `${currentTrack.surahId}_${currentTrack.reciterName}.mp3`);
      setIsDownloading(false);
    } catch (err) {
      console.error(err);
      alert('نەتوانرا فایلەکە دابەزێنرێت.');
      setIsDownloading(false);
    }
  };

  return (
    <div 
      onClick={() => isFullscreenView && setIsFullscreenView(false)}
      className="fixed inset-0 z-50 bg-black text-white font-kufic flex flex-col justify-between overflow-hidden animate-fadeIn"
    >
      {/* 100% Full Screen Video Background with Zero-Lag Seamless Fade-In */}
      <div className="absolute inset-0 z-0 bg-slate-950 overflow-hidden">
        {/* Reciter Still Photo as Base / Loading Backdrop */}
        {currentTrack?.reciterPhoto && (
          <img 
            src={currentTrack.reciterPhoto} 
            alt={currentTrack.reciterName} 
            className={`w-full h-full object-cover transition-opacity duration-700 ${
              isVideoLoaded && selectedVideo ? 'opacity-0 pointer-events-none' : 'opacity-50'
            }`}
            onError={(e) => {
              e.target.onerror = null;
              e.target.src = '/images/logo_light.png';
            }}
          />
        )}

        {/* Seamless Background Video Supporting All Android Versions */}
        {selectedVideo && (
          <video
            ref={videoRef}
            key={selectedVideo}
            autoPlay
            loop
            muted
            playsInline
            webkit-playsinline="true"
            x5-playsinline="true"
            preload="auto"
            disablePictureInPicture
            controls={false}
            onLoadedData={() => setIsVideoLoaded(true)}
            onLoadedMetadata={() => setIsVideoLoaded(true)}
            onPlaying={() => setIsVideoLoaded(true)}
            onCanPlay={() => setIsVideoLoaded(true)}
            onTimeUpdate={() => { if (!isVideoLoaded) setIsVideoLoaded(true); }}
            onError={() => {
              console.warn('Video background load error, falling back to backdrop photo');
              setIsVideoLoaded(false);
            }}
            className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-500 ${
              isVideoLoaded ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <source src={selectedVideo} type="video/mp4" />
          </video>
        )}

        {!isFullscreenView && (
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-black/80 pointer-events-none transition-opacity duration-300" />
        )}
      </div>

      {/* TOP HEADER BAR (Hidden in Fullscreen mode) */}
      {!isFullscreenView && (
        <div className="relative z-10 p-6 pt-12 sm:pt-6 flex items-center justify-between transition-all">
          {/* Back Button */}
          <button 
            onClick={onBack}
            className="flex items-center gap-2 text-white font-bold text-base hover:opacity-80 active:scale-95 transition-all cursor-pointer drop-shadow-md"
          >
            <ChevronRight className="w-6 h-6 text-white" />
            <span>گەڕانەوە</span>
          </button>

          {/* Action Buttons: Fullscreen Toggle & Download */}
          <div className="flex items-center gap-3">
            {/* FULLSCREEN VIEW TOGGLE BUTTON */}
            <button
              onClick={() => setIsFullscreenView(true)}
              className="w-11 h-11 rounded-full bg-white/20 backdrop-blur-md text-white hover:bg-white/30 flex items-center justify-center shadow-2xl transition-all cursor-pointer border border-white/30"
              title="تەنها ڤیدیۆی باکگراوند"
            >
              <Maximize2 className="w-5 h-5 text-white" />
            </button>

            {/* DOWNLOAD BUTTON */}
            <button
              onClick={handlePlayerDownload}
              disabled={isDownloading}
              className="w-11 h-11 rounded-full bg-white/20 backdrop-blur-md text-white hover:bg-white hover:text-slate-900 flex items-center justify-center shadow-2xl transition-all cursor-pointer border border-white/30"
              title={isOfflineReady ? 'داونلۆدکراوە' : 'داونلۆدکردنی سورەت'}
            >
              {isDownloading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : isOfflineReady ? (
                <Check className="w-5 h-5 text-white font-bold" />
              ) : (
                <Download className="w-5 h-5 text-white" />
              )}
            </button>
          </div>
        </div>
      )}

      {/* Empty space in middle */}
      <div className="relative z-10 my-auto" />

      {/* BOTTOM CONTROLS AREA (Hidden in Fullscreen mode) */}
      {!isFullscreenView && (
        <div className="relative z-10 p-6 pb-10 space-y-5 max-w-md mx-auto w-full transition-all">
          {/* CENTER "ڕوونما" BUTTON (Placed cleanly in middle above track info) */}
          <div className="flex justify-center w-full pb-1">
            <button
              onClick={() => setIsBgModalOpen(true)}
              className="py-2.5 px-6 rounded-2xl bg-white/20 backdrop-blur-xl hover:bg-white/30 text-white border border-white/30 transition-all cursor-pointer flex items-center justify-center gap-2 text-sm font-bold shadow-lg active:scale-95"
              title="هەڵبژاردنی ڕوونما"
            >
              <Palette className="w-5 h-5 text-white" />
              <span className="text-white">ڕوونما</span>
            </button>
          </div>

          {/* Surah Name on Right & Reciter Name on Left */}
          <div className="flex items-center justify-between w-full px-1 text-white border-b border-white/15 pb-3">
            {/* RIGHT SIDE: Surah Name */}
            <div className="text-right">
              <h3 className="font-bold text-lg sm:text-xl text-white drop-shadow-md">
                سورة {currentTrack.surahName} <span className="text-xs font-normal text-emerald-200">({currentTrack.surahKurdish})</span>
              </h3>
            </div>

            {/* LEFT SIDE: Reciter Name */}
            <div className="text-left">
              <p className="text-sm font-semibold text-slate-100 drop-shadow-md">
                {currentTrack.reciterName}
              </p>
            </div>
          </div>

          {/* Time Progress Slider */}
          <div className="space-y-1.5 pt-1">
            <input 
              type="range"
              min="0"
              max={duration || 100}
              value={currentTime || 0}
              onChange={(e) => onSeek(Number(e.target.value))}
              className="w-full h-1.5 bg-white/30 rounded-lg appearance-none cursor-pointer accent-white"
            />
            <div className="flex items-center justify-between text-xs font-semibold text-white/90 px-1">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>

          {/* Playback Controls Row */}
          <div className="flex items-center justify-around pt-1">
            <button 
              onClick={onPrevTrack}
              className="p-3 text-white hover:opacity-80 active:scale-90 transition-all cursor-pointer"
              title="سورەتی پێشوو"
            >
              <SkipForward className="w-7 h-7 fill-current text-white" />
            </button>

            <button 
              onClick={onTogglePlay}
              className="w-15 h-15 rounded-full bg-white text-slate-900 flex items-center justify-center shadow-2xl hover:scale-105 active:scale-95 transition-all cursor-pointer"
            >
              {isPlaying ? (
                <Pause className="w-7 h-7 fill-current text-slate-900" />
              ) : (
                <Play className="w-7 h-7 fill-current text-slate-900 ml-0.5" />
              )}
            </button>

            <button 
              onClick={onNextTrack}
              className="p-3 text-white hover:opacity-80 active:scale-90 transition-all cursor-pointer"
              title="سورەتی دواتر"
            >
              <SkipBack className="w-7 h-7 fill-current text-white" />
            </button>
          </div>
        </div>
      )}

      {/* GLASSMORPHISM MODAL: "هەڵبژاردنی ڕوونما" */}
      {isBgModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-lg animate-fadeIn">
          <div className="bg-slate-900/85 backdrop-blur-2xl text-white w-full max-w-md rounded-3xl p-6 border border-white/20 shadow-2xl space-y-6 max-h-[85vh] overflow-y-auto font-kufic">
            {/* Modal Header */}
            <div className="flex items-center justify-between border-b border-white/15 pb-4">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-white" />
                <h3 className="text-lg font-bold text-white">هەڵبژاردنی ڕوونما</h3>
              </div>
              <button 
                onClick={() => setIsBgModalOpen(false)}
                className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
              >
                <X className="w-5 h-5 text-white" />
              </button>
            </div>

            {/* Section 1: Video Background Picker */}
            <div className="space-y-3">
              <h4 className="font-bold text-sm text-white text-right">ڤیدیۆی باکگراوند:</h4>
              <div className="grid grid-cols-2 gap-2.5">
                {VIDEO_OPTIONS.map((video) => {
                  const isSelected = selectedVideo === video.url;
                  const IconComp = video.icon;
                  return (
                    <button
                      key={video.id}
                      onClick={() => handleSelectVideo(video.url)}
                      className={`p-3.5 rounded-2xl text-xs font-bold text-right border transition-all cursor-pointer flex items-center justify-between backdrop-blur-md ${
                        isSelected 
                          ? 'bg-[#14a489] text-white border-emerald-300 shadow-lg scale-[1.02]' 
                          : 'bg-white/10 text-white border-white/15 hover:bg-white/20'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <IconComp className="w-4 h-4 text-white shrink-0" />
                        <span className="line-clamp-1 text-white">{video.name}</span>
                      </div>
                      {isSelected && <Check className="w-4 h-4 text-white font-bold shrink-0" />}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Section 2: Ambient Sound Effect Picker (0% to 100% Volume Range) */}
            <div className="space-y-3 pt-3 border-t border-white/15">
              <h4 className="font-bold text-sm text-white text-right">دەنگی ساوند ئیفێکت:</h4>

              <div className="grid grid-cols-2 gap-2.5">
                {AMBIENT_SOUND_OPTIONS.map((sound) => {
                  const isSelected = selectedAmbient.id === sound.id;
                  const IconComp = sound.icon;
                  return (
                    <button
                      key={sound.id}
                      onClick={() => handleSelectAmbient(sound)}
                      className={`p-3.5 rounded-2xl text-xs font-bold text-right border transition-all cursor-pointer flex items-center justify-between backdrop-blur-md ${
                        isSelected 
                          ? 'bg-[#14a489] text-white border-emerald-300 shadow-lg scale-[1.02]' 
                          : 'bg-white/10 text-white border-white/15 hover:bg-white/20'
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <IconComp className="w-4 h-4 text-white shrink-0" />
                        <span className="line-clamp-1 text-white">{sound.name}</span>
                      </div>
                      {isSelected && <Check className="w-4 h-4 text-white font-bold shrink-0" />}
                    </button>
                  );
                })}
              </div>

              {/* Volume Slider for Ambient Sound (0% to 100%) */}
              {selectedAmbient.url && (
                <div className="pt-3 space-y-2 bg-white/10 backdrop-blur-md p-4 rounded-2xl border border-white/15">
                  <div className="flex items-center justify-between text-xs font-semibold text-white">
                    <span>ئاستی دەنگی ساوند ئیفێکت: {Math.round(ambientVolume * 100)}%</span>
                    <Volume2 className="w-4 h-4 text-white" />
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.02"
                    value={ambientVolume}
                    onChange={(e) => handleVolumeChange(Number(e.target.value))}
                    className="w-full h-1.5 bg-white/30 rounded-lg appearance-none cursor-pointer accent-white"
                  />
                </div>
              )}
            </div>

            <button
              onClick={() => setIsBgModalOpen(false)}
              className="w-full py-3.5 bg-[#14a489] hover:opacity-90 active:scale-95 text-white rounded-2xl font-bold transition-all text-center cursor-pointer shadow-lg text-sm border border-emerald-400/40"
            >
              باشە
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
