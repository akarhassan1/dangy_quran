import React, { useState, useEffect, useRef } from 'react';
import HomeScreen from './components/HomeScreen';
import RecitersScreen from './components/RecitersScreen';
import SurahScreen from './components/SurahScreen';
import PlayerScreen from './components/PlayerScreen';
import RadioScreen from './components/RadioScreen';
import DownloadsScreen from './components/DownloadsScreen';
import MiniPlayer from './components/MiniPlayer';
import InfoModal from './components/InfoModal';
import SettingsModal from './components/SettingsModal';

import { fetchReciters } from './services/api';
import { KURDISH_SURAH_LIST, getSurahAudioUrl } from './services/reciterData';
import { getOfflineAudioUrl } from './services/offlineStorage';

export default function App() {
  // Navigation & History Stack State
  const [currentScreen, setCurrentScreen] = useState('home'); 
  const [historyStack, setHistoryStack] = useState(['home']);
  const [selectedReciter, setSelectedReciter] = useState(null);

  // Reciters catalog
  const [reciters, setReciters] = useState([]);
  const [loadingReciters, setLoadingReciters] = useState(true);

  // Theme & Modals State
  const [darkMode, setDarkMode] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isInfoOpen, setIsInfoOpen] = useState(false);
  const [autoPlayNext, setAutoPlayNext] = useState(true);

  // Audio Playback State
  const audioRef = useRef(new Audio());
  const [currentTrack, setCurrentTrack] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);

  // Restore Last Played Track & Position on App Startup
  useEffect(() => {
    async function restoreLastTrack() {
      try {
        const savedTrackStr = localStorage.getItem('dangy_last_track');
        const savedPosStr = localStorage.getItem('dangy_last_position');

        if (savedTrackStr) {
          const track = JSON.parse(savedTrackStr);
          if (track) {
            let streamUrl = track.audioUrl;
            // If it was an offline track or previous session blob URL, generate fresh Blob URL
            if (track.isOffline || (streamUrl && streamUrl.startsWith('blob:'))) {
              const freshBlobUrl = await getOfflineAudioUrl(track.surahId, track.reciterId);
              if (freshBlobUrl) {
                streamUrl = freshBlobUrl;
                track.audioUrl = freshBlobUrl;
                track.isOffline = true;
              } else if (track.reciterServer) {
                streamUrl = getSurahAudioUrl(track.reciterServer, track.surahId);
                track.audioUrl = streamUrl;
                track.isOffline = false;
              }
            }

            if (streamUrl) {
              setCurrentTrack(track);
              const audio = audioRef.current;
              audio.src = streamUrl;
              audio.load();
              if (savedPosStr) {
                const pos = parseFloat(savedPosStr);
                if (!isNaN(pos) && pos > 0) {
                  audio.currentTime = pos;
                  setCurrentTime(pos);
                }
              }
            }
          }
        }
      } catch (err) {
        console.warn('Error restoring last played track state', err);
      }
    }
    restoreLastTrack();
  }, []);

  // Save currentTrack & currentTime to localStorage
  useEffect(() => {
    if (currentTrack) {
      localStorage.setItem('dangy_last_track', JSON.stringify(currentTrack));
    }
  }, [currentTrack]);

  useEffect(() => {
    if (currentTrack && currentTime > 0) {
      localStorage.setItem('dangy_last_position', String(currentTime));
    }
  }, [currentTime, currentTrack]);

  // Navigate to screen with history stack recording
  const navigateTo = (targetScreen) => {
    if (targetScreen === currentScreen) return;
    setHistoryStack(prev => [...prev, targetScreen]);
    setCurrentScreen(targetScreen);
  };

  // Back button action
  const goBack = () => {
    if (historyStack.length > 1) {
      const newStack = [...historyStack];
      newStack.pop();
      const previousScreen = newStack[newStack.length - 1];
      setHistoryStack(newStack);
      setCurrentScreen(previousScreen);
    } else {
      setCurrentScreen('home');
      setHistoryStack(['home']);
    }
  };

  // Request Notification Permission on App Startup (Android & Web)
  useEffect(() => {
    async function initPermissions() {
      if (window.Capacitor && window.Capacitor.Plugins.MediaNotification) {
        try {
          await window.Capacitor.Plugins.MediaNotification.requestPermission();
        } catch (e) {
          console.warn('Native MediaNotification permission error', e);
        }
      } else if ('Notification' in window && Notification.permission !== 'granted' && Notification.permission !== 'denied') {
        try {
          Notification.requestPermission();
        } catch (e) {}
      }
    }
    initPermissions();
  }, []);

  // Initialize Dark Mode & Load Reciters
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  useEffect(() => {
    async function loadRecitersData() {
      setLoadingReciters(true);
      const list = await fetchReciters();
      setReciters(list);
      setLoadingReciters(false);
    }
    loadRecitersData();
  }, []);

  // Listen to native Android notification button actions (Play, Pause, Prev, Next)
  useEffect(() => {
    if (window.Capacitor && window.Capacitor.Plugins.MediaNotification) {
      const plugin = window.Capacitor.Plugins.MediaNotification;
      const handler = plugin.addListener('onNotificationAction', (data) => {
        if (!data || !data.action) return;
        if (data.action === 'play') {
          audioRef.current.play().then(() => setIsPlaying(true));
        } else if (data.action === 'pause') {
          audioRef.current.pause();
          setIsPlaying(false);
        } else if (data.action === 'next') {
          handleNextTrack(false);
        } else if (data.action === 'previous') {
          handlePrevTrack(false);
        }
      });

      return () => {
        if (handler && handler.remove) handler.remove();
      };
    }
  }, [currentTrack]);

  // Audio event listeners
  useEffect(() => {
    const audio = audioRef.current;

    const handleTimeUpdate = () => setCurrentTime(audio.currentTime);
    const handleLoadedMetadata = () => setDuration(audio.duration || 0);
    const handleEnded = () => {
      setIsPlaying(false);
      if (autoPlayNext && currentTrack && !currentTrack.isRadio) {
        handleNextTrack(false);
      }
    };
    const handleError = (e) => {
      console.error('Audio playback error:', e);
      setIsPlaying(false);
    };

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('ended', handleEnded);
    audio.addEventListener('error', handleError);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('ended', handleEnded);
      audio.removeEventListener('error', handleError);
    };
  }, [currentTrack, autoPlayNext]);

  // Update System Media Notification Bar & Lock Screen Media Player
  useEffect(() => {
    if (!currentTrack) return;

    const titleStr = `سورة ${currentTrack.surahName} (${currentTrack.surahKurdish})`;
    const artistStr = currentTrack.reciterName;
    const photoPath = currentTrack.reciterPhoto || '/images/logo_light.png';

    // 1. Native Capacitor Media Notification (For Android System Notification Shade & Lockscreen)
    if (window.Capacitor && window.Capacitor.Plugins.MediaNotification) {
      window.Capacitor.Plugins.MediaNotification.updateNotification({
        title: titleStr,
        artist: artistStr,
        isPlaying: isPlaying,
        photoUrl: photoPath
      }).catch(e => console.warn('Native updateNotification error', e));
    }

    // 2. Web MediaSession API (For Web Browsers)
    if ('mediaSession' in navigator) {
      try {
        const absolutePhotoUrl = photoPath.startsWith('http') 
          ? photoPath 
          : window.location.origin + photoPath;

        navigator.mediaSession.metadata = new MediaMetadata({
          title: titleStr,
          artist: artistStr,
          album: 'دەنگی قورئان - Dangy Quran',
          artwork: [
            { src: absolutePhotoUrl, sizes: '512x512', type: 'image/png' },
            { src: absolutePhotoUrl, sizes: '256x256', type: 'image/png' }
          ]
        });

        navigator.mediaSession.playbackState = isPlaying ? 'playing' : 'paused';

        navigator.mediaSession.setActionHandler('play', () => {
          audioRef.current.play().then(() => setIsPlaying(true));
        });
        navigator.mediaSession.setActionHandler('pause', () => {
          audioRef.current.pause();
          setIsPlaying(false);
        });
        navigator.mediaSession.setActionHandler('previoustrack', () => handlePrevTrack(false));
        navigator.mediaSession.setActionHandler('nexttrack', () => handleNextTrack(false));
      } catch (err) {
        console.warn('Web MediaSession setup error', err);
      }
    }
  }, [currentTrack, isPlaying]);

  // Handle Play Surah
  const playSurah = async (surah, reciter, openPlayerOnStart = true) => {
    const audio = audioRef.current;
    
    let streamUrl = await getOfflineAudioUrl(surah.id, reciter.id);
    let isOffline = !!streamUrl;

    if (!streamUrl) {
      streamUrl = getSurahAudioUrl(reciter.server, surah.id);
    }

    const fallbackLogo = darkMode ? '/images/logo_dark.png' : '/images/logo_light.png';

    const track = {
      surahId: surah.id,
      surahName: surah.name,
      surahKurdish: surah.kurdishName,
      reciterId: reciter.id,
      reciterName: reciter.name,
      reciterPhoto: reciter.photo || fallbackLogo,
      reciterServer: reciter.server,
      audioUrl: streamUrl,
      isOffline: isOffline,
      isRadio: false
    };

    setCurrentTrack(track);
    audio.src = streamUrl;
    audio.load();
    const playPromise = audio.play();
    if (playPromise !== undefined) {
      playPromise.then(() => {
        setIsPlaying(true);
      }).catch(err => {
        console.warn('Auto-play blocked or failed', err);
      });
    }

    if (openPlayerOnStart) {
      navigateTo('player');
    }
  };

  // Handle Play Offline Audio
  const playOfflineAudio = (item, blobUrl) => {
    const audio = audioRef.current;
    const fallbackLogo = darkMode ? '/images/logo_dark.png' : '/images/logo_light.png';

    // Find reciter server if available
    const reciterMatch = reciters.find(r => r.id === item.reciterId);
    const reciterServer = item.reciterServer || (reciterMatch ? reciterMatch.server : '');

    const track = {
      surahId: item.surahId,
      surahName: item.surahArabic || item.surahName,
      surahKurdish: item.surahName,
      reciterId: item.reciterId,
      reciterName: item.reciterName,
      reciterPhoto: item.reciterPhoto || fallbackLogo,
      reciterServer: reciterServer,
      audioUrl: blobUrl,
      isOffline: true,
      isRadio: false
    };

    setCurrentTrack(track);
    audio.src = blobUrl;
    audio.load();
    const playPromise = audio.play();
    if (playPromise !== undefined) {
      playPromise.then(() => setIsPlaying(true)).catch(e => console.warn('Offline audio play error', e));
    }
    navigateTo('player');
  };

  // Toggle Play / Pause
  const togglePlayPause = () => {
    const audio = audioRef.current;
    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio.play().then(() => setIsPlaying(true));
    }
  };

  // Seek time
  const handleSeek = (newTime) => {
    const audio = audioRef.current;
    audio.currentTime = newTime;
    setCurrentTime(newTime);
  };

  // Next Track
  const handleNextTrack = (openPlayerOnStart = false) => {
    if (!currentTrack || currentTrack.isRadio) return;
    const nextSurahId = currentTrack.surahId >= 114 ? 1 : currentTrack.surahId + 1;
    const nextSurah = KURDISH_SURAH_LIST.find(s => s.id === nextSurahId);
    const reciterObj = reciters.find(r => r.id === currentTrack.reciterId) || {
      id: currentTrack.reciterId,
      name: currentTrack.reciterName,
      photo: currentTrack.reciterPhoto,
      server: currentTrack.reciterServer
    };
    if (nextSurah) {
      playSurah(nextSurah, reciterObj, openPlayerOnStart);
    }
  };

  // Previous Track
  const handlePrevTrack = (openPlayerOnStart = false) => {
    if (!currentTrack || currentTrack.isRadio) return;
    const prevSurahId = currentTrack.surahId <= 1 ? 114 : currentTrack.surahId - 1;
    const prevSurah = KURDISH_SURAH_LIST.find(s => s.id === prevSurahId);
    const reciterObj = reciters.find(r => r.id === currentTrack.reciterId) || {
      id: currentTrack.reciterId,
      name: currentTrack.reciterName,
      photo: currentTrack.reciterPhoto,
      server: currentTrack.reciterServer
    };
    if (prevSurah) {
      playSurah(prevSurah, reciterObj, openPlayerOnStart);
    }
  };

  // Close player bar
  const handleClosePlayer = () => {
    const audio = audioRef.current;
    audio.pause();
    setIsPlaying(false);
    setCurrentTrack(null);
    localStorage.removeItem('dangy_last_track');
    localStorage.removeItem('dangy_last_position');
    if (window.Capacitor && window.Capacitor.Plugins.MediaNotification) {
      window.Capacitor.Plugins.MediaNotification.dismissNotification().catch(e => {});
    }
    if ('mediaSession' in navigator) {
      navigator.mediaSession.playbackState = 'none';
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#011142] font-kufic antialiased text-slate-800 dark:text-slate-100 selection:bg-[#14a489] selection:text-white transition-colors duration-300">
      {/* View router */}
      {currentScreen === 'home' && (
        <HomeScreen
          onNavigate={(screen) => navigateTo(screen)}
          onOpenSettings={() => setIsSettingsOpen(true)}
          onOpenInfo={() => setIsInfoOpen(true)}
          darkMode={darkMode}
          setDarkMode={setDarkMode}
        />
      )}

      {currentScreen === 'reciters' && (
        <RecitersScreen
          reciters={reciters}
          loading={loadingReciters}
          darkMode={darkMode}
          onSelectReciter={(reciter) => {
            setSelectedReciter(reciter);
            navigateTo('surahs');
          }}
          onBack={goBack}
        />
      )}

      {currentScreen === 'surahs' && selectedReciter && (
        <SurahScreen
          reciter={selectedReciter}
          currentTrack={currentTrack}
          darkMode={darkMode}
          onPlaySurah={(surah, reciter) => playSurah(surah, reciter, true)}
          onBack={goBack}
        />
      )}

      {currentScreen === 'player' && currentTrack && (
        <PlayerScreen
          currentTrack={currentTrack}
          isPlaying={isPlaying}
          darkMode={darkMode}
          onTogglePlay={togglePlayPause}
          onNextTrack={() => handleNextTrack(true)}
          onPrevTrack={() => handlePrevTrack(true)}
          currentTime={currentTime}
          duration={duration}
          onSeek={handleSeek}
          onBack={goBack}
        />
      )}

      {currentScreen === 'radio' && (
        <RadioScreen
          onBack={goBack}
        />
      )}

      {currentScreen === 'downloads' && (
        <DownloadsScreen
          currentTrack={currentTrack}
          darkMode={darkMode}
          onPlayOfflineAudio={playOfflineAudio}
          onBack={goBack}
        />
      )}

      {/* Floating Bottom Mini Player */}
      {currentTrack && currentScreen !== 'player' && (
        <MiniPlayer
          currentTrack={currentTrack}
          isPlaying={isPlaying}
          darkMode={darkMode}
          onTogglePlay={togglePlayPause}
          onOpenFullPlayer={() => navigateTo('player')}
          onClosePlayer={handleClosePlayer}
        />
      )}

      {/* Modals */}
      <InfoModal 
        isOpen={isInfoOpen} 
        onClose={() => setIsInfoOpen(false)} 
      />

      <SettingsModal 
        isOpen={isSettingsOpen} 
        onClose={() => setIsSettingsOpen(false)}
        autoPlayNext={autoPlayNext}
        setAutoPlayNext={setAutoPlayNext}
      />
    </div>
  );
}
