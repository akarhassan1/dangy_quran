import { get, set, del, keys } from 'idb-keyval';
import { CapacitorHttp, Capacitor } from '@capacitor/core';

// Prefix key for indexedDB items
const AUDIO_PREFIX = 'quran_audio_';
const META_PREFIX = 'quran_meta_';

/**
 * Convert Base64 string to Uint8Array safely without stack overflow
 */
export function base64ToUint8Array(base64) {
  const cleanBase64 = base64.replace(/^data:[^;]+;base64,/, '').trim();
  const binaryString = atob(cleanBase64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

/**
 * Convert any data format (Blob, ArrayBuffer, Uint8Array, Base64 string) to Uint8Array
 */
export async function toUint8Array(data) {
  if (!data) throw new Error('Data is empty or null');
  if (data instanceof Uint8Array) return data;
  if (data instanceof ArrayBuffer) return new Uint8Array(data);
  if (ArrayBuffer.isView(data)) return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
  if (data instanceof Blob) {
    const ab = await data.arrayBuffer();
    return new Uint8Array(ab);
  }
  if (typeof data === 'string') {
    return base64ToUint8Array(data);
  }
  throw new Error('Unsupported audio data format');
}

/**
 * Robust fetch audio blob with Native Capacitor HTTP, CORS handling, and Redirect Follow
 * Supports GitHub Releases, TVQuran, Archive.org, MP3Quran, and all custom reciter servers
 */
export async function fetchAudioBlob(url) {
  if (!url) throw new Error('Invalid audio URL');
  let cleanUrl = url.trim().replace(/^http:\/\//i, 'https://');

  // Strategy 1: Native CapacitorHttp (Bypasses all CORS and follows 302 redirects natively on Android & iOS)
  if (Capacitor.isNativePlatform()) {
    try {
      const resNative = await CapacitorHttp.get({
        url: cleanUrl,
        responseType: 'blob',
        connectTimeout: 25000,
        readTimeout: 40000
      });

      if (resNative && resNative.status >= 200 && resNative.status < 300 && resNative.data) {
        let uint8Array;
        if (typeof resNative.data === 'string') {
          uint8Array = base64ToUint8Array(resNative.data);
        } else {
          uint8Array = await toUint8Array(resNative.data);
        }

        if (uint8Array.length > 1000) {
          return new Blob([uint8Array], { type: 'audio/mpeg' });
        }
      }
    } catch (eNative) {
      console.warn('Native CapacitorHttp fetch error, attempting fallback:', eNative);
    }
  }

  // Strategy 2: Standard fetch with CORS and redirect follow
  try {
    const res = await fetch(cleanUrl, {
      method: 'GET',
      mode: 'cors',
      redirect: 'follow',
      headers: {
        'Accept': 'audio/mpeg, audio/*, */*'
      }
    });

    if (res.ok && res.status >= 200 && res.status < 300) {
      const blob = await res.blob();
      if (blob && blob.size > 1000) {
        return blob;
      }
    }
  } catch (e1) {
    console.warn('Standard CORS fetch failed for:', cleanUrl, e1);
  }

  // Strategy 3: GitHub Releases URL special handling
  if (cleanUrl.includes('github.com')) {
    if (cleanUrl.includes('/raw/')) {
      const rawUrl = cleanUrl.replace('github.com', 'raw.githubusercontent.com').replace('/raw/', '/');
      try {
        const resRaw = await fetch(rawUrl, { method: 'GET', mode: 'cors' });
        if (resRaw.ok && resRaw.status === 200) {
          const blob = await resRaw.blob();
          if (blob && blob.size > 1000) return blob;
        }
      } catch (eRaw) {}
    }
  }

  // Strategy 4: Fallback through CapacitorHttp even on web if available
  try {
    const resCap = await CapacitorHttp.get({
      url: cleanUrl,
      responseType: 'blob'
    });
    if (resCap && resCap.status >= 200 && resCap.status < 300 && resCap.data) {
      const uint8 = typeof resCap.data === 'string' ? base64ToUint8Array(resCap.data) : await toUint8Array(resCap.data);
      if (uint8.length > 1000) {
        return new Blob([uint8], { type: 'audio/mpeg' });
      }
    }
  } catch (eCap) {}

  // Strategy 5: Web CORS proxy fallback for development / web preview
  if (!Capacitor.isNativePlatform()) {
    try {
      const proxyUrl = `https://corsproxy.io/?${encodeURIComponent(cleanUrl)}`;
      const resProxy = await fetch(proxyUrl);
      if (resProxy.ok) {
        const blob = await resProxy.blob();
        if (blob && blob.size > 1000) return blob;
      }
    } catch (eProxy) {}
  }

  throw new Error(`Failed to download audio from: ${cleanUrl}`);
}

/**
 * Save audio file Uint8Array to IndexedDB for robust offline playback across all Android OS versions
 */
export async function saveAudioOffline(surahId, reciterId, audioData, metadata = {}) {
  const key = `${AUDIO_PREFIX}${reciterId}_${surahId}`;
  const metaKey = `${META_PREFIX}${reciterId}_${surahId}`;
  
  // Convert audioData to Uint8Array for bulletproof IndexedDB persistence
  const uint8Array = await toUint8Array(audioData);
  if (!uint8Array || uint8Array.length < 1000) {
    throw new Error('Audio data is too small or corrupt');
  }

  // Store binary Uint8Array in IndexedDB
  await set(key, uint8Array);
  
  // Store metadata (Surah name, reciter name, date added, size, server)
  const meta = {
    ...metadata,
    reciterId,
    surahId: Number(surahId),
    downloadedAt: new Date().toISOString(),
    size: uint8Array.length
  };
  await set(metaKey, meta);
  return key;
}

/**
 * Get offline audio URL (generates a valid, fresh Blob object URL)
 */
export async function getOfflineAudioUrl(surahId, reciterId) {
  const key = `${AUDIO_PREFIX}${reciterId}_${surahId}`;
  const data = await get(key);
  if (!data) return null;
  
  try {
    let blob;
    if (data instanceof Blob) {
      blob = data;
    } else if (data instanceof Uint8Array || data instanceof ArrayBuffer || ArrayBuffer.isView(data)) {
      blob = new Blob([data], { type: 'audio/mpeg' });
    } else if (typeof data === 'string') {
      const bytes = base64ToUint8Array(data);
      blob = new Blob([bytes], { type: 'audio/mpeg' });
    } else {
      return null;
    }

    if (blob.size < 1000) {
      console.warn('Stored offline audio blob is invalid or empty:', blob.size);
      return null;
    }

    return URL.createObjectURL(blob);
  } catch (err) {
    console.error('Error generating offline audio URL:', err);
    return null;
  }
}

/**
 * Check if a specific Surah by Reciter is available offline
 */
export async function isAudioOffline(surahId, reciterId) {
  const key = `${AUDIO_PREFIX}${reciterId}_${surahId}`;
  const data = await get(key);
  if (!data) return false;
  if (data instanceof Uint8Array || data instanceof ArrayBuffer) return data.byteLength > 1000;
  if (data instanceof Blob) return data.size > 1000;
  if (typeof data === 'string') return data.length > 1000;
  return false;
}

/**
 * Delete offline audio
 */
export async function deleteOfflineAudio(surahId, reciterId) {
  const key = `${AUDIO_PREFIX}${reciterId}_${surahId}`;
  const metaKey = `${META_PREFIX}${reciterId}_${surahId}`;
  await del(key);
  await del(metaKey);
}

/**
 * Get all downloaded offline audio metadata
 */
export async function getAllOfflineAudios() {
  const allKeys = await keys();
  const metaKeys = allKeys.filter(k => typeof k === 'string' && k.startsWith(META_PREFIX));
  const result = [];
  
  for (const mKey of metaKeys) {
    const meta = await get(mKey);
    if (meta && meta.surahId) {
      result.push(meta);
    }
  }
  return result;
}

/**
 * Trigger direct file download in browser / mobile
 */
export function downloadFileToDisk(blobOrUrl, filename) {
  try {
    const url = typeof blobOrUrl === 'string' ? blobOrUrl : URL.createObjectURL(blobOrUrl);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.target = '_blank';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    if (typeof blobOrUrl !== 'string') {
      setTimeout(() => URL.revokeObjectURL(url), 10000);
    }
  } catch (err) {
    console.warn('downloadFileToDisk error:', err);
  }
}
