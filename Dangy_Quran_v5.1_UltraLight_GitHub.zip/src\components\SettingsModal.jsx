import React, { useState } from 'react';
import { X, Sliders, Trash2, Check, Bell } from 'lucide-react';
import { clear as clearIDB } from 'idb-keyval';

export default function SettingsModal({ isOpen, onClose, autoPlayNext, setAutoPlayNext, onClearCache }) {
  const [clearedMsg, setClearedMsg] = useState(false);
  const [notifPermission, setNotifPermission] = useState(() => {
    if ('Notification' in window) return Notification.permission;
    return 'default';
  });

  if (!isOpen) return null;

  const handleRequestNotif = async () => {
    if (window.Capacitor && window.Capacitor.Plugins.MediaNotification) {
      try {
        const res = await window.Capacitor.Plugins.MediaNotification.requestPermission();
        if (res && res.granted) {
          setNotifPermission('granted');
          alert('ڕێگەپێدانی نۆتفیکەیشن بە سەرکەوتوویی چالاکرا!');
        } else {
          alert('تکایە لە ڕێکخستنەکانی مۆبایلەکەتدا (App Settings) ڕێگەپێدانی نۆتفیکەیشن بۆ ئەپەکە کارابکە.');
        }
      } catch (e) {
        console.warn(e);
      }
    } else if ('Notification' in window) {
      try {
        const perm = await Notification.requestPermission();
        setNotifPermission(perm);
        if (perm === 'granted') {
          alert('ڕێگەپێدانی نۆتفیکەیشن بە سەرکەوتوویی چالاکرا!');
        }
      } catch (e) {
        console.warn(e);
      }
    }
  };

  const handleClearCache = async () => {
    if (window.confirm('ئایا دڵنیایت لە سڕینەوەی سەرجەم فایلی دەنگە داونلۆدکراوەکان بۆ ئۆفلاین؟')) {
      await clearIDB();
      setClearedMsg(true);
      if (onClearCache) onClearCache();
      setTimeout(() => setClearedMsg(false), 3000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn font-kufic" dir="rtl">
      <div className="bg-white dark:bg-[#011142] w-full max-w-md rounded-3xl shadow-2xl overflow-hidden border border-slate-200 dark:border-blue-900/60 text-slate-800 dark:text-slate-100 transition-all">
        {/* Modal Header */}
        <div className="bg-[#14a489] dark:bg-blue-900 px-6 py-5 text-white flex items-center justify-between" dir="rtl">
          <div className="flex items-center gap-3">
            <Sliders className="w-6 h-6" />
            <h3 className="text-xl font-bold">ڕێکخستنەکان</h3>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="p-6 space-y-6 text-right" dir="rtl">
          {/* Setting 1: Notification Permission (Strict RTL: Title on FAR RIGHT, Button on FAR LEFT) */}
          <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-blue-950/60 border border-slate-200/80 dark:border-blue-900/40" dir="rtl">
            {/* FAR RIGHT: Title and Subtitle */}
            <div className="text-right flex-1 pl-3">
              <h4 className="font-semibold text-slate-800 dark:text-slate-100 text-sm flex items-center gap-1.5">
                <Bell className="w-4 h-4 text-[#14a489] dark:text-blue-400 shrink-0" />
                <span>ڕێگەپێدانی نۆتفیکەیشن</span>
              </h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 text-right mt-1 leading-relaxed">
                بۆ نیشاندانی کۆنتڕۆڵی دەنگەکە لە نۆتفیکەیشن باڕدا
              </p>
            </div>

            {/* FAR LEFT: Action Button */}
            <button
              onClick={handleRequestNotif}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer border shrink-0 ${
                notifPermission === 'granted'
                  ? 'bg-emerald-100 dark:bg-blue-900/60 text-[#14a489] dark:text-blue-300 border-emerald-300 dark:border-blue-500'
                  : 'bg-[#14a489] dark:bg-blue-600 text-white border-transparent hover:opacity-90 active:scale-95'
              }`}
            >
              {notifPermission === 'granted' ? 'چالاکراوە ✓' : 'چالاکردن'}
            </button>
          </div>

          {/* Setting 2: Auto Play Next (Strict RTL: Title on FAR RIGHT, Toggle on FAR LEFT) */}
          <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-50 dark:bg-blue-950/60 border border-slate-200/80 dark:border-blue-900/40" dir="rtl">
            <div className="text-right flex-1 pl-3">
              <h4 className="font-semibold text-slate-800 dark:text-slate-100 text-sm">لێدانی خۆکارانەی سورەتی دواتر</h4>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-relaxed">کاتێک سورەتێک تەواو دەبێت ڕاستەوخۆ دەچێتە سەر دواتر</p>
            </div>
            <button
              onClick={() => setAutoPlayNext(!autoPlayNext)}
              className={`w-12 h-7 flex items-center rounded-full p-1 transition-colors cursor-pointer shrink-0 ${
                autoPlayNext ? 'bg-[#14a489] dark:bg-blue-600 justify-end' : 'bg-slate-300 dark:bg-slate-700 justify-start'
              }`}
            >
              <div className="w-5 h-5 rounded-full bg-white shadow-md transform transition-transform" />
            </button>
          </div>

          {/* Setting 3: Clear Cache */}
          <div className="pt-2 border-t border-slate-100 dark:border-blue-900/40 space-y-3" dir="rtl">
            <h4 className="font-semibold text-slate-800 dark:text-slate-100 text-sm">بەڕێوەبردنی مێمۆری</h4>
            <button
              onClick={handleClearCache}
              className="w-full py-3 px-4 rounded-2xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/50 text-rose-600 dark:text-rose-400 hover:bg-rose-100 dark:hover:bg-rose-950/70 font-semibold text-sm flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              <Trash2 className="w-4 h-4" />
              <span>پاککردنەوەی فایلی ئۆفلاین (کاش)</span>
            </button>
            {clearedMsg && (
              <p className="text-center text-xs text-[#14a489] dark:text-blue-400 flex items-center justify-center gap-1">
                <Check className="w-4 h-4" />
                <span>سەرجەم فایلەکان سڕدرانەوە!</span>
              </p>
            )}
          </div>

          <button
            onClick={onClose}
            className="w-full py-3 bg-[#14a489] dark:bg-blue-800 hover:opacity-90 active:scale-95 text-white rounded-2xl font-bold shadow-md transition-all text-center cursor-pointer"
          >
            باشە
          </button>
        </div>
      </div>
    </div>
  );
}
