import React, { useState, useEffect } from 'react';
import { ChevronRight, Play, Download, Check, Search, Volume2 } from 'lucide-react';
import { KURDISH_SURAH_LIST, getSurahAudioUrl } from '../services/reciterData';
import { isAudioOffline, saveAudioOffline, downloadFileToDisk, fetchAudioBlob } from '../services/offlineStorage';
import { normalizeArabicSearch } from '../services/api';

export default function SurahScreen({ 
  reciter, 
  onPlaySurah, 
  onBack, 
  currentTrack,
  darkMode
}) {
  const [searchQuery, setSearchQuery] = useState('');
  const [offlineStatusMap, setOfflineStatusMap] = useState({});
  const [downloadingSurahId, setDownloadingSurahId] = useState(null);

  const fallbackLogo = darkMode || (typeof document !== 'undefined' && document.documentElement.classList.contains('dark'))
    ? '/images/logo_dark.png' 
    : '/images/logo_light.png';

  const photoSrc = reciter.photo || fallbackLogo;

  useEffect(() => {
    async function checkOfflineFiles() {
      if (!reciter) return;
      const statusMap = {};
      for (const surah of KURDISH_SURAH_LIST) {
        const cached = await isAudioOffline(surah.id, reciter.id);
        if (cached) statusMap[surah.id] = true;
      }
      setOfflineStatusMap(statusMap);
    }
    checkOfflineFiles();
  }, [reciter]);

  const handleDownload = async (surah, e) => {
    if (e) e.stopPropagation();
    if (downloadingSurahId) return;

    try {
      setDownloadingSurahId(surah.id);
      const audioUrl = getSurahAudioUrl(reciter.server, surah.id);
      
      const blob = await fetchAudioBlob(audioUrl);

      const metadata = {
        surahName: surah.kurdishName,
        surahArabic: surah.name,
        reciterName: reciter.name,
        reciterPhoto: photoSrc,
        reciterServer: reciter.server,
        verses: surah.verses,
        type: surah.type
      };

      await saveAudioOffline(surah.id, reciter.id, blob, metadata);
      setOfflineStatusMap(prev => ({ ...prev, [surah.id]: true }));

      downloadFileToDisk(blob, `${surah.id}_${reciter.name}_${surah.kurdishName}.mp3`);

      setTimeout(() => {
        setDownloadingSurahId(null);
      }, 500);

    } catch (err) {
      console.error('Download error:', err);
      alert('نەتوانرا فایلەکە داونلۆد بکرێت. تکایە هێڵی ئینتەرنێتەکەت بپشکنە.');
      setDownloadingSurahId(null);
    }
  };

  // Smart Diacritics-Insensitive Surah Search
  const normQuery = normalizeArabicSearch(searchQuery);
  const filteredSurahs = KURDISH_SURAH_LIST.filter(s => 
    normalizeArabicSearch(s.kurdishName).includes(normQuery) ||
    normalizeArabicSearch(s.name).includes(normQuery) ||
    String(s.id).includes(normQuery)
  );

  return (
    <div className="min-h-screen pb-28 font-kufic bg-slate-50 dark:bg-[#011142] text-slate-800 dark:text-white transition-colors duration-300">
      {/* Top Banner with pt-12 clearance for mobile status bar */}
      <div className="bg-[#14a489] dark:bg-blue-900/80 text-white pt-12 sm:pt-6 pb-6 px-6 shadow-sm">
        <div className="max-w-md mx-auto flex items-center justify-between mb-3">
          <button 
            onClick={onBack}
            className="flex items-center gap-2 hover:opacity-80 active:scale-95 transition-all font-semibold cursor-pointer"
          >
            <ChevronRight className="w-6 h-6" />
            <span className="text-lg">گەڕانەوە</span>
          </button>
        </div>

        {/* Selected Reciter Info */}
        <div className="max-w-md mx-auto flex items-center gap-4 pt-1">
          <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-white/80 shadow-sm shrink-0 bg-white dark:bg-[#011142] flex items-center justify-center">
            <img 
              src={photoSrc} 
              alt={reciter.name} 
              className="w-full h-full object-cover"
              onError={(e) => {
                e.target.onerror = null;
                e.target.src = fallbackLogo;
              }}
            />
          </div>
          <div className="text-right space-y-0.5">
            <h1 className="text-xl font-extrabold text-white">
              {reciter.name}
            </h1>
            <p className="text-xs text-emerald-100 dark:text-blue-200">
              {reciter.rewaya || 'حفص عن عاصم'} • ١١٤ سورەت
            </p>
          </div>
        </div>

        {/* Search */}
        <div className="max-w-md mx-auto mt-4 relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="گەڕان بۆ ناوی سورەت..."
            className="w-full py-2.5 pr-10 pl-4 rounded-xl bg-white/10 border border-white/20 text-white placeholder-emerald-100/70 focus:outline-none font-kufic text-sm text-right"
          />
          <Search className="w-4 h-4 absolute right-3.5 top-1/2 -translate-y-1/2 text-white/70 pointer-events-none" />
        </div>
      </div>

      {/* Surahs List */}
      <div className="max-w-md mx-auto px-4 pt-4 space-y-2.5">
        {filteredSurahs.map((surah) => {
          const isPlayingThis = currentTrack?.surahId === surah.id && currentTrack?.reciterId === reciter.id;
          const isOffline = offlineStatusMap[surah.id];
          const isDownloading = downloadingSurahId === surah.id;

          return (
            <div
              key={surah.id}
              onClick={() => onPlaySurah(surah, reciter)}
              className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between group ${
                isPlayingThis 
                  ? 'bg-emerald-50 dark:bg-blue-900/60 border-[#14a489] dark:border-blue-500 shadow-sm' 
                  : 'bg-white dark:bg-blue-950/40 border-slate-200 dark:border-blue-900/40 hover:border-[#14a489]'
              }`}
            >
              {/* RIGHT SIDE: Surah Number + Surah Name & Info */}
              <div className="text-right flex items-center gap-3">
                <div className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-blue-900/50 text-[#14a489] dark:text-blue-300 font-extrabold text-sm flex items-center justify-center shrink-0 font-arabic border border-slate-200/60 dark:border-blue-800/40">
                  {surah.id}
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <h3 className={`font-bold text-base transition-colors ${
                      isPlayingThis ? 'text-[#14a489] dark:text-blue-400' : 'text-slate-800 dark:text-slate-100'
                    }`}>
                      سورة {surah.name}
                    </h3>
                    <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                      ({surah.kurdishName})
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-400 dark:text-slate-400 mt-0.5">
                    <span>{surah.type}</span>
                    <span>•</span>
                    <span>{surah.verses} ئایەت</span>
                    {isOffline && (
                      <span className="text-[10px] bg-emerald-100 dark:bg-blue-900 text-[#14a489] dark:text-blue-300 px-1.5 py-0.2 rounded font-bold">
                        ئۆفلاین
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* LEFT SIDE: Download Icon & Play Icon */}
              <div className="flex items-center gap-2">
                <button
                  onClick={(e) => handleDownload(surah, e)}
                  disabled={isDownloading}
                  className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
                    isOffline 
                      ? 'bg-emerald-100 dark:bg-blue-900 text-[#14a489] dark:text-blue-300' 
                      : 'bg-slate-100 dark:bg-blue-900/40 hover:bg-[#14a489] hover:text-white text-slate-500 dark:text-slate-300'
                  }`}
                  title={isOffline ? 'داونلۆدکراوە' : 'داونلۆدکردن'}
                >
                  {isDownloading ? (
                    <div className="w-4 h-4 border-2 border-[#14a489] border-t-transparent rounded-full animate-spin" />
                  ) : isOffline ? (
                    <Check className="w-4 h-4 font-bold" />
                  ) : (
                    <Download className="w-4 h-4" />
                  )}
                </button>

                <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-sm transition-all ${
                  isPlayingThis
                    ? 'bg-[#14a489] dark:bg-blue-600 text-white'
                    : 'bg-slate-100 dark:bg-blue-900/40 text-[#14a489] dark:text-blue-300 group-hover:bg-[#14a489] group-hover:text-white'
                }`}>
                  {isPlayingThis ? (
                    <Volume2 className="w-4 h-4 animate-pulse" />
                  ) : (
                    <Play className="w-4 h-4 ml-0.5 fill-current" />
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
