import React, { useState } from 'react';
import { ChevronRight, Search } from 'lucide-react';
import { normalizeArabicSearch } from '../services/api';

export default function RecitersScreen({ 
  reciters, 
  onSelectReciter, 
  onBack, 
  loading,
  darkMode
}) {
  const [searchQuery, setSearchQuery] = useState('');

  // Smart Diacritics-Insensitive Search
  const normQuery = normalizeArabicSearch(searchQuery);
  const filteredReciters = reciters.filter(r => 
    normalizeArabicSearch(r.name).includes(normQuery)
  );

  const fallbackLogo = darkMode || (typeof document !== 'undefined' && document.documentElement.classList.contains('dark'))
    ? '/images/logo_dark.png' 
    : '/images/logo_light.png';

  return (
    <div className="min-h-screen pb-28 font-kufic bg-slate-50 dark:bg-[#011142] text-slate-800 dark:text-white transition-colors duration-300">
      {/* Top Banner Header with pt-12 clearance for mobile status bar */}
      <div className="bg-[#14a489] dark:bg-blue-900/80 text-white pt-12 sm:pt-8 pb-10 px-6 header-arch-shape relative shadow-sm">
        <div className="max-w-4xl mx-auto flex items-center justify-between">
          <button 
            onClick={onBack}
            className="flex items-center gap-2 hover:opacity-80 active:scale-95 transition-all text-white font-semibold cursor-pointer"
          >
            <ChevronRight className="w-6 h-6" />
            <span className="text-lg">گەڕانەوە</span>
          </button>
        </div>

        {/* Header Title */}
        <div className="max-w-4xl mx-auto text-center pt-3 pb-2">
          <h1 className="text-3xl sm:text-4xl font-extrabold tracking-wide">
            قورئان خوێنەکان
          </h1>
          <p className="text-emerald-100 dark:text-blue-200 text-xs sm:text-sm mt-1">گوێگرتن لە سورەتەکان بە دەنگی قورئان خوێنە جیهانییەکان</p>
        </div>

        {/* Search Bar */}
        <div className="max-w-md mx-auto mt-4 relative">
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="گەڕان بۆ ناوی قورئان خوێن..."
            className="w-full py-3 pr-11 pl-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 text-white placeholder-emerald-100/70 focus:outline-none focus:ring-2 focus:ring-white/40 font-kufic text-sm transition-all text-right"
          />
          <Search className="w-5 h-5 absolute right-4 top-1/2 -translate-y-1/2 text-white/70 pointer-events-none" />
        </div>
      </div>

      {/* Reciters Grid Container */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 pt-8">
        {loading ? (
          <div className="py-16 text-center space-y-3">
            <div className="w-12 h-12 border-4 border-[#14a489] dark:border-blue-400 border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-sm text-slate-500 dark:text-slate-400">داواکردنی قورئان خوێنەکان لە سێرڤەر...</p>
          </div>
        ) : filteredReciters.length === 0 ? (
          <div className="py-16 text-center text-slate-500 dark:text-slate-400">
            هیچ قورئان خوێنێک بەم ناوە نەدۆزرایەوە!
          </div>
        ) : (
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-y-8 gap-x-4">
            {filteredReciters.map((reciter) => {
              const photoSrc = reciter.photo || fallbackLogo;

              return (
                <button
                  key={reciter.id}
                  onClick={() => onSelectReciter(reciter)}
                  className="flex flex-col items-center group cursor-pointer text-center focus:outline-none"
                >
                  {/* Circular Reciter Avatar */}
                  <div className="relative mb-3">
                    <div className="w-22 h-22 sm:w-24 sm:h-24 md:w-28 md:h-28 rounded-full overflow-hidden shadow-sm border-3 border-white dark:border-blue-900 group-hover:scale-105 group-active:scale-95 transition-all duration-300 ring-2 ring-[#14a489]/30 dark:ring-blue-500/40 group-hover:ring-[#14a489] dark:group-hover:ring-blue-400 bg-white dark:bg-[#011142] flex items-center justify-center">
                      <img 
                        src={photoSrc} 
                        alt={reciter.name}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          e.target.onerror = null;
                          e.target.src = fallbackLogo;
                        }}
                      />
                    </div>
                  </div>

                  {/* Reciter Name */}
                  <h3 className="font-bold text-xs sm:text-sm text-slate-800 dark:text-slate-100 group-hover:text-[#14a489] dark:group-hover:text-blue-400 line-clamp-2 transition-colors leading-snug px-1">
                    {reciter.name}
                  </h3>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
