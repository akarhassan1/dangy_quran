import customRecitersData from '../../public/names v2.json';
import cachedRecitersData from '../../public/cached_reciters.json';

const BASE_URL = 'https://www.mp3quran.net/api/v3';

// Complete list of all reciter image files present in public/images/reciters/
const ALL_RECITER_IMAGE_FILES = [
  "hussary.jpg",
  "mahr_maqle.jpg",
  "minshawi.jpg",
  "qatami.jpg",
  "sad_alhamdi.jpg",
  "salmanaletb.jpg",
  "sawdalshrem.jpg",
  "shuraim.png",
  "sudais.jpg",
  "xaldalqtadhe.jpg",
  "yasser.jpg",
  "أحمد الحذيفي.jpg",
  "أحمد الحواشي.jpg",
  "أحمد السويلم.jpg",
  "أحمد الطرابلسي.jpg",
  "أحمد النفيس .jpg",
  "أحمد بن علي العجمي.jpg",
  "أحمد خليل شاهين.jpg",
  "أحمد ديبان.jpg",
  "أحمد سعود.jpg",
  "أحمد صابر.jpg",
  "أحمد طالب بن حميد.jpg",
  "أحمد عامر.png",
  "أحمد عيسى المعصراوي.jpg",
  "أحمد نعينع.jpg",
  "أخيل عبدالحي روا.jpg",
  "أستاذ زامري.jpg",
  "أكرم العلاقمي.jpg",
  "أنس العمادي.jpg",
  "أيمن سويد.jpg",
  "إبراهيم الجبرين.jpg",
  "إبراهيم الجرمي.jpg",
  "إبراهيم الدوسري.jpg",
  "إبراهيم السعدان.jpg",
  "إبراهيم الشهري.webp",
  "إبراهيم العسيري.jpg",
  "إدريس أبكر.jpg",
  "إسلام صبحي.jpg",
  "ابراهيم الأخضر.jpg",
  "الزين محمد أحمد.jpg",
  "العشري عمران.jpg",
  "الوليد الشمسان.jpg",
  "بدر التركي.jpeg",
  "بندر بليله.jpg",
  "تامر اسلام.jpg",
  "توفيق الصايغ.jpg",
  "جمال الدين الزيلعي.jpg",
  "جمال شاكر عبدالله.png",
  "جمعان العصيمي.png",
  "جنيد آدم عبدالله.jpg",
  "حاتم فريد الواعر.jpg",
  "حسن الدغريري.jpg",
  "حسن صالح.png",
  "حسين آل الشيخ.jpg",
  "حمد الدغريري.jpg",
  "خالد الجليل.jpg",
  "خالد الزيادي.webp",
  "خالد الشارخ.jpeg",
  "خالد الغامدي.jpg",
  "خالد المهنا.jpg",
  "خالد الوهيبي.jpg",
  "خالد عبدالكافي.jpg",
  "خالد كريم محمدي.jpg",
  "خليفة الطنيجي.jpg",
  "داود حمزة.jpg",
  "رامي الدعيس.jpg",
  "رشيد بلعالية.webp",
  "رضية عبدالرحمن.png",
  "رقية سولونق.jpg",
  "زكريا حمامة.jpg",
  "زكي داغستاني.jpg",
  "سامي الحسن.jpg",
  "سامي الدوسري.jpg",
  "سعد الغامدي.jpg",
  "سعد المقرن.jpg",
  "سلمان الصديق.jpg",
  "سهل ياسين.jpg",
  "سيد أحمد هاشمي.jpg",
  "سیدین عبدالرحمن.png",
  "شعبان الصياد.jpg",
  "شيخ أبو بكر الشاطري.jpg",
  "شيرزاد عبدالرحمن طاهر.jpg",
  "صابر عبدالحكم.jpg",
  "صالح آل طالب.jpg",
  "صالح الشمراني.jpg",
  "صالح الصاهود.jpg",
  "صالح القريشي.jpeg",
  "صالح الهبدان.webp",
  "صلاح البدير.jpg",
  "صلاح الهاشم.jpg",
  "صلاح بو خاطر.jpg",
  "صلاح مصلي.jpg",
  "عادل الكلباني.jpg",
  "عادل ريان.jpg",
  "عاصم اللحیدان.jpg",
  "عامر الکاظمي.jpg",
  "عبد الرشيد صوفي.jpg",
  "عبدالإله بن عون.jpg",
  "عبدالبارئ الثبيتي.jpg",
  "عبدالبارئ محمد.jpg",
  "عبدالباسط عبدالصمد.jpg",
  "عبدالبديع غيلان.jpg",
  "عبدالرحمن السويّد.jpg",
  "عبدالرحمن الشحات.jpg",
  "عبدالرحمن العوسي.jpg",
  "عبدالرحمن الماجد.jpg",
  "عبدالرحمن بن عبدالرزاق البدر.jpg",
  "عبدالرشيد صوفي.jpg",
  "عبدالعزيز الأحمد.jpg",
  "عبدالعزيز التركي.jpg",
  "عبدالعزيز الزهراني.jpg",
  "عبدالعزيز العسيري.jpg",
  "عبدالغني عبدالله.jpg",
  "عبدالكريم الحازمي.jpg",
  "عبدالله البريمي.jpg",
  "عبدالله البعيجان.jpg",
  "عبدالله الخلف.jpg",
  "عبدالله القرافي.jpg",
  "عبدالله الكندري.jpg",
  "عبدالله المشعل.jpg",
  "عبدالله المطرود.jpg",
  "عبدالله الموسى.jpg",
  "عبدالله بخاري.jpg",
  "عبدالله بصفر.jpeg",
  "عبدالله خياط.png",
  "عبدالله عبدل.jpg",
  "عبدالله عواد الجهني.jpg",
  "عبدالله غيلان.jpg",
  "عبدالله فهمي.jpg",
  "عبدالله كامل.jpeg",
  "عبدالمجيد الأركاني.jpg",
  "عبدالمحسن الحارثي.jpg",
  "عبدالمحسن العبيكان.jpg",
  "عبدالمحسن العسكر.jpg",
  "عبدالمحسن القاسم.jpg",
  "عبدالملك العسكر.jpg",
  "عبدالهادي أحمد كناكري.jpg",
  "عبدالهادی.jpg",
  "عبدالودود حنيف.jpg",
  "عبدالولي الأركاني.jpg",
  "عثمان الأنصاري.jpg",
  "علي أبو هاشم.jpg",
  "علي بن عبدالرحمن الحذيفي.jpg",
  "علي جابر.jpg",
  "علي حجاج السويسي.jpg",
  "عماد زهير حافظ.jpg",
  "عمر الدريويز.jpg",
  "عمر القزابري.jpg",
  "عيسى عمر سناكو.jpg",
  "غسان الشوربجي.jpg",
  "فؤاد الخامري.jpg",
  "فارس عباد.jpg",
  "فهد العتيبي.jpg",
  "فهد الكندري.jpg",
  "فواز الكعبي.jpg",
  "فيصل الهاجري.jpg",
  "فەرمان شوانی.jpg",
  "لافي العوني.jpg",
  "ماجد الزامل.jpg",
  "ماجد العنزي.jpeg",
  "مال الله عبدالرحمن الجابر.jpg",
  "ماهر المعيقلي.png",
  "ماهر شخاشيرو.jpg",
  "محمد أيوب.jpeg",
  "محمد البخيت.jpg",
  "محمد البراك.jpg",
  "محمد الحافظ.jpg",
  "محمد الزبيدي.jpg",
  "محمد الطبلاوي.jpg",
  "محمد الفقيه.jpg",
  "محمد اللحيدان.jpg",
  "محمد المحيسني.jpg",
  "محمد المنشد.jpg",
  "محمد برهجي.jpg",
  "محمد جبريل.jpg",
  "محمد خليل القارئ.jpg",
  "محمد خير النور.jpg",
  "محمد رشاد الشريف.jpg",
  "محمد رفعت.jpg",
  "محمد صالح عالم شاه.png",
  "محمد صديق المنشاوي.jpg",
  "محمد عبدالكريم.jpg",
  "محمد عثمان خان.jpg",
  "محمود الرفاعي.jpg",
  "محمود حرفوش.webp",
  "محمود خليل الحصري.jpg",
  "محمود عبدالحكم.jpg",
  "محمود علي البنا.jpg",
  "محی الدین الکردی.jpg",
  "مختار الحاج.jpg",
  "مشاري العفاسي.jpg",
  "مشاري بن راشد العفاسي.jpg",
  "مصطفى إسماعيل.jpg",
  "مصطفى اللاهوني.jpg",
  "معمر الأندونيسي.jpg",
  "معيض الحارثي.jpg",
  "مفتاح السلطني.jpg",
  "منصور السالمي.jpg",
  "موسى بلال.jpg",
  "ناصر العبيد.jpg",
  "ناصر العصفور.jpg",
  "ناصر القطامي.jpg",
  "ناصر الماجد.jpg",
  "نبيل بن عبدالرحيم الرفاعي.jpg",
  "نذير المالكي.jpg",
  "نعمة الحسان.jpg",
  "نورين محمد صديق.jpg",
  "هارون بقائي.jpg",
  "هاشم أبو دلال.jpg",
  "هاني الرفاعي.jpg",
  "هزاع البلوشي.jpg",
  "هيثم الجدعاني.jpg",
  "هيثم الدخين.jpg",
  "واصل المذن.jpg",
  "وديع اليمني.jpg",
  "وشيار حيدر اربيلي.jpg",
  "وليد الدليمي.jpg",
  "ياسر الدوسري.jpg",
  "ياسر الفيلكاوي.jpg",
  "ياسر القرشي.jpg",
  "ياسر سلامة.jpg",
  "يحيى حوا.jpg",
  "يوسف الدغوش.jpg",
  "يوسف الشويعي.jpg",
  "يوسف العيدروس.jpg",
  "يوسف بن نوح أحمد.jpg",
  "پێشەوا قادر.jpg",
  "ڕزگار محمد.jpg",
  "ڕعد محمد.jpg",
  "ڕمضان شکور.jpg"
];

/**
 * Smart Diacritics-Insensitive Search & String Normalizer for Arabic & Kurdish
 */
export function normalizeArabicSearch(text) {
  if (!text) return '';
  return text
    .trim()
    .toLowerCase()
    .replace(/[\u064B-\u065F\u0670\u200B-\u200F\uFEFF]/g, '')
    .replace(/[أإآٱ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/[ىيئێی]/g, 'ي')
    .replace(/[ۆؤ]/g, 'و')
    .replace(/[كک]/g, 'ك')
    .replace(/[گ]/g, 'ك')
    .replace(/[پ]/g, 'ب')
    .replace(/[ڤ]/g, 'ف')
    .replace(/[ڕ]/g, 'ر')
    .replace(/[\(\)\[\]\-_\.]/g, ' ')
    .replace(/\s+/g, ' ');
}

/**
 * Extract core significant keywords from reciter name (ignores honorifics like Sheikh, Dr, Bin, etc.)
 */
function getCoreKeywords(name) {
  const n = normalizeArabicSearch(name);
  return n.split(' ').filter(w => 
    w.length > 2 && 
    !['بن', 'ابن', 'عبد', 'ابو', 'الشيخ', 'القارئ', 'دكتور', 'الدكتور', 'مرتل'].includes(w)
  );
}

/**
 * Intelligent Duplicate Reciter Detector
 */
export function isDuplicateReciter(nameA, nameB) {
  if (!nameA || !nameB) return false;
  const normA = normalizeArabicSearch(nameA);
  const normB = normalizeArabicSearch(nameB);

  // Exact normalized match
  if (normA === normB) return true;

  // Specific check for Afasy
  if ((normA.includes('عفاسي') || normA.includes('alafasy')) && (normB.includes('عفاسي') || normB.includes('alafasy'))) return true;

  // Check known alias pairs
  for (const [p1, p2] of ALIAS_PAIRS) {
    const np1 = normalizeArabicSearch(p1);
    const np2 = normalizeArabicSearch(p2);
    if ((normA === np1 && normB === np2) || (normA === np2 && normB === np1)) return true;
    if ((normA.includes(np1) && normB.includes(np2)) || (normA.includes(np2) && normB.includes(np1))) return true;
  }

  // Substring match (for names with length > 4)
  if (normA.length > 4 && (normA.includes(normB) || normB.includes(normA))) return true;

  // Core keywords match (e.g., "مشاري بن راشد العفاسي" vs "مشاري العفاسي")
  const kwA = getCoreKeywords(nameA);
  const kwB = getCoreKeywords(nameB);
  if (kwA.length >= 2 && kwB.length >= 2) {
    if (kwA.every(k => kwB.includes(k)) || kwB.every(k => kwA.includes(k))) return true;
  }

  return false;
}

/**
 * Get exact matching photo URL for reciter from public/images/reciters/
 */
export function getReciterPhoto(name) {
  if (!name) return null;
  const normName = normalizeArabicSearch(name);

  // Direct known aliases for non-standard image names
  if (normName.includes('سديس') || normName.includes('sudais')) return '/images/reciters/sudais.jpg';
  if (normName.includes('شريم') || normName.includes('shuraim') || normName.includes('شريفي')) return '/images/reciters/shuraim.png';
  if (normName.includes('عتيبي') && normName.includes('سلمان')) return '/images/reciters/salmanaletb.jpg';
  if (normName.includes('قحطاني') && normName.includes('خالد')) return '/images/reciters/xaldalqtadhe.jpg';
  if (normName.includes('حسان') || (normName.includes('حسن') && normName.includes('نعمه'))) return '/images/reciters/نعمة الحسان.jpg';
  if (normName.includes('بيشوا') || normName.includes('بيشه وا') || normName.includes('پيشه وا') || normName.includes('پێشەوا')) return '/images/reciters/پێشەوا قادر.jpg';
  if (normName.includes('رمضان') || normName.includes('ڕمضان')) return '/images/reciters/ڕمضان شکور.jpg';
  if (normName.includes('رزگار') || normName.includes('ڕزگار')) return '/images/reciters/ڕزگار محمد.jpg';
  if (normName.includes('رعد') || normName.includes('ڕعد')) return '/images/reciters/ڕعد محمد.jpg';
  if (normName.includes('شواني') || normName.includes('شوانی')) return '/images/reciters/فەرمان شوانی.jpg';
  if (normName.includes('عفاسي') || normName.includes('alafasy')) return '/images/reciters/مشاري العفاسي.jpg';
  if (normName.includes('معيقلي') || normName.includes('maher')) return '/images/reciters/ماهر المعيقلي.png';
  if (normName.includes('منشاوي') || normName.includes('minshawi')) return '/images/reciters/محمد صديق المنشاوي.jpg';
  if (normName.includes('حصري') || normName.includes('hussary')) return '/images/reciters/محمود خليل الحصري.jpg';
  if (normName.includes('قطامي') || normName.includes('qatami')) return '/images/reciters/ناصر القطامي.jpg';
  if (normName.includes('دوسري') && normName.includes('ياسر')) return '/images/reciters/ياسر الدوسري.jpg';
  if (normName.includes('غامدي') && normName.includes('سعد')) return '/images/reciters/سعد الغامدي.jpg';
  if (normName.includes('رفاعي') && normName.includes('نبيل')) return '/images/reciters/نبيل بن عبدالرحيم الرفاعي.jpg';
  if (normName.includes('رفاعي') && normName.includes('هاني')) return '/images/reciters/هاني الرفاعي.jpg';

  // 1. Exact match after full normalization
  for (const filename of ALL_RECITER_IMAGE_FILES) {
    const baseName = filename.replace(/\.(jpg|jpeg|png|webp)$/i, '');
    const normBase = normalizeArabicSearch(baseName);

    if (normName === normBase) {
      return `/images/reciters/${filename}`;
    }
  }

  // 2. Substring match
  for (const filename of ALL_RECITER_IMAGE_FILES) {
    const baseName = filename.replace(/\.(jpg|jpeg|png|webp)$/i, '');
    const normBase = normalizeArabicSearch(baseName);

    if (normBase.length > 3 && (normName.includes(normBase) || normBase.includes(normName))) {
      return `/images/reciters/${filename}`;
    }
  }

  // 3. Keyword match
  const nameWords = normName.split(' ').filter(w => w.length > 2 && !['بن', 'ابن', 'عبد', 'ابو', 'الشيخ', 'القارئ', 'دكتور'].includes(w));
  for (const filename of ALL_RECITER_IMAGE_FILES) {
    const baseName = filename.replace(/\.(jpg|jpeg|png|webp)$/i, '');
    const normBase = normalizeArabicSearch(baseName);
    const fileWords = normBase.split(' ').filter(w => w.length > 2 && !['بن', 'ابن', 'عبد', 'ابو', 'الشيخ', 'القارئ', 'دكتور'].includes(w));

    if (nameWords.length >= 2 && fileWords.length >= 2) {
      if (nameWords.every(w => normBase.includes(w)) || fileWords.every(w => normName.includes(w))) {
        return `/images/reciters/${filename}`;
      }
    }
  }
  return null;
}


/**
 * Fetch reciters list with 100% Offline Pre-Caching and Strict Deduplication
 */
export async function fetchReciters(language = 'ar') {
  // Check local cache first for instant offline loading
  try {
    const localCachedStr = localStorage.getItem('dangy_cached_reciters_catalog');
    if (localCachedStr) {
      const parsed = JSON.parse(localCachedStr);
      if (Array.isArray(parsed) && parsed.length > 50) {
        // Sync online in background without blocking UI
        syncOnlineReciters(language);
        return parsed;
      }
    }
  } catch (e) {}

  // If no local storage cache, use bundled static pre-cache (230+ reciters)
  if (Array.isArray(cachedRecitersData) && cachedRecitersData.length > 50) {
    syncOnlineReciters(language);
    return cachedRecitersData;
  }

  return buildMergedRecitersList(language);
}

/**
 * Background online sync
 */
async function syncOnlineReciters(language) {
  try {
    const list = await buildMergedRecitersList(language);
    if (list && list.length > 50) {
      localStorage.setItem('dangy_cached_reciters_catalog', JSON.stringify(list));
    }
  } catch (e) {}
}

/**
 * Build merged and deduplicated reciter catalog
 */
async function buildMergedRecitersList(language = 'ar') {
  const merged = [];

  // 1. Process custom reciters from names v2.json (Highest Priority)
  for (const item of customRecitersData) {
    const reciterName = (item.name_ar || item.language_en || '').trim();
    if (!reciterName || reciterName.includes('هەندرێن') || reciterName.includes('هندرين') || reciterName.includes('Hendren')) {
      continue;
    }

    let serverUrl = (item.url || item.language_fr || '').trim();
    if (!serverUrl) continue;
    if (!serverUrl.endsWith('/')) serverUrl += '/';

    // Avoid duplicate within custom list
    if (!merged.some(m => isDuplicateReciter(m.name, reciterName))) {
      merged.push({
        id: `custom_${item.id}`,
        apiId: item.id,
        name: reciterName,
        rewaya: 'حفص عن عاصم',
        server: serverUrl,
        photo: getReciterPhoto(reciterName),
        availableSurahs: Array.from({ length: 114 }, (_, i) => i + 1)
      });
    }
  }

  // 2. Fetch and merge unique reciters from MP3Quran API v3
  try {
    const res = await fetch(`${BASE_URL}/reciters?language=${language}&rewaya=1`);
    if (res.ok) {
      const data = await res.json();
      const apiReciters = data.reciters || [];

      for (const r of apiReciters) {
        const moshaf = r.moshaf && r.moshaf.length > 0 ? r.moshaf[0] : null;
        if (!moshaf || !moshaf.server) continue;

        const apiName = (r.name || '').trim();
        if (!apiName || apiName.includes('هەندرێن') || apiName.includes('هندرين') || apiName.includes('Hendren')) {
          continue;
        }

        // STRICT DEDUPLICATION: Skip if already present in merged list
        if (merged.some(m => isDuplicateReciter(m.name, apiName))) {
          continue;
        }

        const surahListStr = moshaf.surah_list || '';
        const availableSurahs = surahListStr 
          ? surahListStr.split(',').map(Number).filter(n => !isNaN(n) && n > 0)
          : Array.from({ length: 114 }, (_, i) => i + 1);

        if (availableSurahs.length === 0) continue;

        let serverUrl = moshaf.server.trim();
        if (!serverUrl.endsWith('/')) serverUrl += '/';

        merged.push({
          id: `api_${r.id}`,
          apiId: r.id,
          name: apiName,
          letter: r.letter,
          rewaya: moshaf.name || 'حفص عن عاصم',
          server: serverUrl,
          photo: getReciterPhoto(apiName),
          availableSurahs: availableSurahs
        });
      }
    }
  } catch (err) {
    console.warn('Network error fetching MP3Quran API reciters, continuing with cached/custom reciters', err);
  }

  return merged;
}

/**
 * Static fallback list when offline
 */
function getFallbackRecitersList() {
  return [
    {
      id: "api_125",
      name: "مشاري العفاسي",
      rewaya: "حفص عن عاصم",
      server: "https://server8.mp3quran.net/afs/",
      photo: getReciterPhoto("مشاري العفاسي"),
      availableSurahs: Array.from({ length: 114 }, (_, i) => i + 1)
    },
    {
      id: "api_102",
      name: "ماهر المعيقلي",
      rewaya: "حفص عن عاصم",
      server: "https://server12.mp3quran.net/maher/",
      photo: getReciterPhoto("ماهر المعيقلي"),
      availableSurahs: Array.from({ length: 114 }, (_, i) => i + 1)
    },
    {
      id: "api_53",
      name: "عبدالرحمن السديس",
      rewaya: "حفص عن عاصم",
      server: "https://server11.mp3quran.net/sds/",
      photo: getReciterPhoto("عبدالرحمن السديس"),
      availableSurahs: Array.from({ length: 114 }, (_, i) => i + 1)
    },
    {
      id: "api_92",
      name: "سعد الغامدي",
      rewaya: "حفص عن عاصم",
      server: "https://server7.mp3quran.net/s_gmd/",
      photo: getReciterPhoto("سعد الغامدي"),
      availableSurahs: Array.from({ length: 114 }, (_, i) => i + 1)
    },
    {
      id: "api_128",
      name: "ياسر الدوسري",
      rewaya: "حفص عن عاصم",
      server: "https://server11.mp3quran.net/dosr/",
      photo: getReciterPhoto("ياسر الدوسري"),
      availableSurahs: Array.from({ length: 114 }, (_, i) => i + 1)
    }
  ];
}
