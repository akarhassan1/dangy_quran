import React from 'react';
import { X, Shield, Download, BookOpen, Send, Globe, MessageCircle } from 'lucide-react';

export default function InfoModal({ isOpen, onClose }) {
  if (!isOpen) return null;

  const handleOpenLink = (url) => {
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn" dir="rtl">
      <div className="bg-white dark:bg-[#011142] w-full max-w-md rounded-3xl shadow-2xl overflow-hidden border border-slate-200 dark:border-blue-900/60 text-slate-800 dark:text-slate-100 transition-all font-kufic max-h-[90vh] flex flex-col">
        {/* Modal Header */}
        <div className="bg-[#14a489] dark:bg-blue-900 px-6 py-4 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <BookOpen className="w-6 h-6" />
            <h3 className="text-xl font-bold">دەربارەی بەرنامە</h3>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-5 text-right overflow-y-auto">
          {/* Logo & Version Banner */}
          <div className="text-center space-y-2 pb-4 border-b border-slate-100 dark:border-blue-900/40">
            <div className="w-20 h-20 rounded-2xl mx-auto overflow-hidden shadow-md border border-slate-200 dark:border-blue-800">
              <img 
                src="/images/logo_light.png" 
                alt="Dangy Quran Logo" 
                className="w-full h-full object-cover dark:hidden"
              />
              <img 
                src="/images/logo_dark.png" 
                alt="Dangy Quran Dark Logo" 
                className="w-full h-full object-cover hidden dark:block"
              />
            </div>
            <h4 className="text-2xl font-bold text-[#14a489] dark:text-blue-400">دەنگی قورئان</h4>
            <div className="flex items-center justify-center gap-2">
              <span className="text-xs text-slate-500 dark:text-slate-400">گوێگرتن لە قورئانی پیرۆز</span>
              <span className="text-[11px] font-bold bg-emerald-100 dark:bg-blue-900/60 text-[#14a489] dark:text-blue-300 px-2.5 py-0.5 rounded-full">
                وەشان 5.1
              </span>
            </div>
          </div>

          {/* App Description */}
          <div className="space-y-3 text-sm leading-relaxed text-slate-600 dark:text-slate-300">
            <p>
              بەرنامەی <strong className="text-[#14a489] dark:text-blue-400">دەنگی قورئان</strong> پەرەپێدراوە بۆ خزمەتکردنی موسڵمانان لە گوێگرتن لە سورەتەکانی قورئانی پیرۆز بە دەنگی قورئان خوێنە بەناوبانگەکان بە کوالێتی بەرز بە ئۆنلاین و ئۆفلاین.
            </p>
            
            <div className="bg-emerald-50 dark:bg-blue-950/60 p-4 rounded-2xl border border-emerald-200/50 dark:border-blue-900/50 space-y-2">
              <div className="flex items-center gap-2 text-[#14a489] dark:text-blue-300 font-semibold text-sm">
                <Download className="w-4 h-4" />
                <span>تایبەتمەندی ئۆفلاین (بێ ئینتەرنێت):</span>
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                دەتوانیت هەر سورەتێک داونلۆد بکەیت تاوەکو لە ناو مێمۆری مۆبایلەکەتدا پاشەکەوت ببێت و لە کاتی نەبوونی ئینتەرنێتیش بە ئاسانی گوێی لێ بگریت.
              </p>
            </div>
          </div>

          {/* Contact Us Section (بەشی پەیوەندیکردن) */}
          <div className="pt-2 border-t border-slate-100 dark:border-blue-900/40 space-y-3">
            <h4 className="font-bold text-slate-800 dark:text-slate-100 text-sm flex items-center gap-2">
              <MessageCircle className="w-4 h-4 text-[#14a489] dark:text-blue-400" />
              <span>پەیوەندیکردن و تۆڕە کۆمەڵایەتییەکان</span>
            </h4>

            <div className="grid grid-cols-1 gap-2.5">
              {/* Telegram Button */}
              <button
                onClick={() => handleOpenLink('https://t.me/SunnahDev')}
                className="w-full p-3.5 rounded-2xl bg-sky-50 dark:bg-sky-950/40 border border-sky-200 dark:border-sky-800/50 hover:bg-sky-100 dark:hover:bg-sky-900/50 transition-all flex items-center justify-between cursor-pointer group shadow-sm active:scale-98"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-sky-500 text-white flex items-center justify-center shadow-md">
                    <Send className="w-4 h-4" />
                  </div>
                  <div className="text-right">
                    <h5 className="font-bold text-slate-800 dark:text-slate-100 text-xs">کەناڵی فەرمی تیلیگرام</h5>
                    <p className="text-[11px] text-sky-600 dark:text-sky-400 font-semibold" dir="ltr">@SunnahDev</p>
                  </div>
                </div>
                <span className="text-xs font-bold text-sky-600 dark:text-sky-400 bg-sky-100 dark:bg-sky-900/60 px-2.5 py-1 rounded-lg">
                  سەردانکردن
                </span>
              </button>

              {/* Facebook Button */}
              <button
                onClick={() => handleOpenLink('https://www.facebook.com/sunnahdev')}
                className="w-full p-3.5 rounded-2xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800/50 hover:bg-blue-100 dark:hover:bg-blue-900/50 transition-all flex items-center justify-between cursor-pointer group shadow-sm active:scale-98"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-md">
                    <Globe className="w-4 h-4" />
                  </div>
                  <div className="text-right">
                    <h5 className="font-bold text-slate-800 dark:text-slate-100 text-xs">پەیجی فەرمی فەیسبووک</h5>
                    <p className="text-[11px] text-blue-600 dark:text-blue-400 font-semibold" dir="ltr">facebook.com/sunnahdev</p>
                  </div>
                </div>
                <span className="text-xs font-bold text-blue-600 dark:text-blue-400 bg-blue-100 dark:bg-blue-900/60 px-2.5 py-1 rounded-lg">
                  سەردانکردن
                </span>
              </button>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-full py-3 bg-[#14a489] dark:bg-blue-800 hover:opacity-90 active:scale-95 text-white rounded-2xl font-bold shadow-md transition-all text-center cursor-pointer mt-2"
          >
            داخستن
          </button>
        </div>
      </div>
    </div>
  );
}
