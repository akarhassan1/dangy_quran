import React, { useState, useEffect } from 'react';
import { ChevronRight, Download, Play, Trash2, HardDrive, Volume2 } from 'lucide-react';
import { getAllOfflineAudios, deleteOfflineAudio, getOfflineAudioUrl } from '../services/offlineStorage';

export default function DownloadsScreen({ onPlayOfflineAudio, currentTrack, onBack }) {
  const [offlineAudios, setOfflineAudios] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  const loadOfflineFiles = async () => {
    setLoading(true);
    const files = await getAllOfflineAudios();
    setOfflineAudios(files);
    setLoading(false);
  };

  useEffect(() => {
    loadOfflineFiles();
  }, []);

  const handleDelete = async (item, e) => {
    e.stopPropagation();
    if (window.confirm(`ئایا دڵنیایت لە سڕینەوەی (${item.surahName}) لە ئۆفلاین؟`)) {
      await deleteOfflineAudio(item.surahId, item.reciterId);
      loadOfflineFiles();
    }
  };

  const handlePlay = async (item) => {
    const blobUrl = await getOfflineAudioUrl(item.surahId, item.reciterId);
    if (blobUrl) {
      onPlayOfflineAudio(item, blobUrl);
    } else {
      alert('فایلەکە لە مێمۆری نەدۆزرایەوە.');
    }
  };

  const filtered = offlineAudios.filter(i => 
    i.surahName?.includes(searchQuery) ||
    i.surahArabic?.includes(searchQuery) ||
    i.reciterName?.includes(searchQuery)
  );

  const totalSizeBytes = offlineAudios.reduce((acc, curr) => acc + (curr.size || 0), 0);
  const totalSizeMB = (totalSizeBytes / (1024 * 1024)).toFixed(1);

  return (
    <div className="min-h-screen pb-28 font-kufic bg-slate-50 dark:bg-[#011142] text-slate-800 dark:text-white transition-colors duration-300">
      {/* Top Banner with pt-12 clearance for mobile status bar */}
      <div className="bg-[#14a489] dark:bg-blue-900/80 text-white pt-12 sm:pt-6 pb-6 px-6 shadow-sm">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <button 
            onClick={onBack}
            className="flex items-center gap-2 hover:opacity-80 active:scale-95 transition-all text-white font-semibold cursor-pointer"
          >
            <ChevronRight className="w-6 h-6" />
            <span className="text-lg">گەڕانەوە</span>
          </button>
        </div>

        <div className="max-w-md mx-auto text-center pt-4 pb-2">
          <h1 className="text-3xl font-extrabold flex items-center justify-center gap-2">
            <span>داونلۆدکراوەکان</span>
            <Download className="w-7 h-7" />
          </h1>
          <p className="text-emerald-100 dark:text-blue-200 text-xs mt-1">سەرجەم دەنگە داونلۆد کراوەکان</p>
        </div>

        {/* Stats card: Surah count on RIGHT, Total size on RIGHT */}
        <div className="max-w-md mx-auto mt-4 bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-3 flex items-center justify-between px-5 text-sm">
          <span className="font-bold text-emerald-100 text-right">
            {offlineAudios.length} سورەت دابەزێنراوە
          </span>
          <span className="flex items-center gap-2 font-semibold">
            <HardDrive className="w-4 h-4 text-emerald-200" />
            <span>حەجم: {totalSizeMB} MB</span>
          </span>
        </div>
      </div>

      {/* Downloads List */}
      <div className="max-w-md mx-auto px-4 pt-4 space-y-2.5">
        {loading ? (
          <div className="py-16 text-center space-y-3">
            <div className="w-12 h-12 border-4 border-[#14a489] dark:border-blue-400 border-t-transparent rounded-full animate-spin mx-auto" />
            <p className="text-sm text-slate-500 dark:text-slate-400">پشکنینی داتاکانی ئۆفلاین...</p>
          </div>
        ) : filtered.length === 0 ? (
          <div className="py-16 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-50 dark:bg-blue-950/60 text-[#14a489] dark:text-blue-400 mx-auto flex items-center justify-center">
              <Download className="w-8 h-8 opacity-60" />
            </div>
            <p className="text-slate-500 dark:text-slate-400 font-semibold text-sm">
              هیچ سورەتێک داونلۆد نەکراوە بۆ ئۆفلاین!
            </p>
            <p className="text-xs text-slate-400 dark:text-slate-500 max-w-xs mx-auto">
              دەتوانیت لە لیستەی سورەتەکان کلیک لەسەر دوگمەی داونلۆد بکەیت تاوەکو بە ئۆفلاین گوێی لێ بگریت.
            </p>
          </div>
        ) : (
          filtered.map((item) => {
            const isPlayingThis = currentTrack?.surahId === item.surahId && currentTrack?.reciterId === item.reciterId;

            return (
              <div
                key={`${item.reciterId}_${item.surahId}`}
                onClick={() => handlePlay(item)}
                className={`p-3.5 rounded-2xl border transition-all cursor-pointer flex items-center justify-between group ${
                  isPlayingThis 
                    ? 'bg-emerald-50 dark:bg-blue-900/60 border-[#14a489] dark:border-blue-500 shadow-sm' 
                    : 'bg-white dark:bg-blue-950/40 border-slate-200 dark:border-blue-900/40 hover:border-[#14a489]'
                }`}
              >
                {/* RIGHT SIDE: Reciter Photo & Surah / Reciter Info */}
                <div className="text-right flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl overflow-hidden shadow-sm shrink-0 bg-white dark:bg-blue-900 flex items-center justify-center">
                    <img 
                      src={item.reciterPhoto} 
                      alt={item.reciterName} 
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        e.target.onerror = null;
                        e.target.src = '/images/logo_light.png';
                      }}
                    />
                  </div>
                  <div>
                    <h3 className="font-bold text-base text-slate-800 dark:text-slate-100">
                      سورة {item.surahArabic || item.surahName} ({item.surahName})
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {item.reciterName}
                    </p>
                  </div>
                </div>

                {/* LEFT SIDE: Play and Delete buttons */}
                <div className="flex items-center gap-2">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold transition-all ${
                    isPlayingThis ? 'bg-[#14a489] dark:bg-blue-600 text-white' : 'bg-emerald-50 dark:bg-blue-900/40 text-[#14a489] dark:text-blue-300'
                  }`}>
                    {isPlayingThis ? <Volume2 className="w-4 h-4 animate-pulse" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
                  </div>

                  <button
                    onClick={(e) => handleDelete(item, e)}
                    className="w-9 h-9 rounded-xl bg-rose-50 dark:bg-rose-950/50 text-rose-600 hover:bg-rose-600 hover:text-white transition-colors flex items-center justify-center cursor-pointer"
                    title="سڕینەوە"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
